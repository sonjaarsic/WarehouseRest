package rs.ac.fink.vezbe;
import java.util.ArrayList;
import java.util.List;
import rs.ac.fink.vezbe.data.*;
import rs.ac.fink.vezbe.exception.ShopException;
import rs.ac.fink.vezbe.service.*;

import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.List;

import static java.util.Arrays.sort;


public class OnlineShopDemo {

    private static final ProductService productService = ProductService.getInstance();

    private static final CustomerService customerService = CustomerService.getInstance();
    private static final CustomersService customersService = CustomersService.getInstance();
    private static final SuppliersService suppliersService = SuppliersService.getInstance();
    private static final ProductsService productsService = ProductsService.getInstance();
    private static final OrdersService ordersService = OrdersService.getInstance();
    private static final ShippersService shippersService = ShippersService.getInstance();
    private static final EmployeesService employeesService = EmployeesService.getInstance();

    private static final PurchaseService purchaseService = PurchaseService.getInstance();

   /* public static void main(String[] args) throws Exception {
     //  addTestCustomer();
        //addTestShipper();
       // addTestOrders();
      //  addTestEmployee();
       // retrieveCustomerOrderInfo();

       listN();
        //findProductsSuppliers() ;
        System.out.print(listN());


       /System.out.print(retrieveCustomerOrderInfo());
     //   System.out.print(findOrders());
        //System.out.print(findEveryCustomers());
       // findEveryCustomer();
      //  addTestSupplier();
      //  addTestProduct();
        //System.out.print(findProductOne());
        //findProductOne();
        //Collections.sort(findEvery());
        //System.out.print(sort(findEvery()));
       System.out.print(findProductsSuppliers());
       // addTestCategories();
        //Assuming that we already have user "branko" and a product "Transformers" in database we can make the following purchase ...
				//Customer korisnik = customerService.findCustomer("branko");
			//	Product transformersIgracka = productService.findProduct("Transformers");
			//	purchaseService.makePurchase(korisnik, transformersIgracka);
    }*/

    private static void deleteTestProducts() throws ShopException {
        productService.deleteProduct("Mali Princ");
        productService.deleteProduct("Transformers");
        productService.deleteProduct("Igra Prestola");
        productService.deleteProduct("Lego kocke");
    }

    private static void addTestCategories() throws ShopException {
        productService.addNewProductCategory(new Category("Book"));
        productService.addNewProductCategory(new Category("Toy"));
    }

    private static void addTestProducts() throws ShopException {
        Category book = productService.findProductCategory("Book");
        Category toy = productService.findProductCategory("Toy");

        Product maliPrinc = new Product("Mali Princ", 30, 10, book);
        productService.addNewProduct(maliPrinc);
        Product igraPrestola = new Product("Igra Prestola", 45, 15, book);
        productService.addNewProduct(igraPrestola);

        Product transformers = new Product("Transformers", 40, 5, toy);
        productService.addNewProduct(transformers);
        Product legoKocke = new Product("Lego kocke", 50, 10, toy);
        productService.addNewProduct(legoKocke);
    }
    private static void addTestProduct() throws ShopException {
        Suppliers supplier = suppliersService.findSupplier(1);

        Products maliPrinc = new Products(1,"Mali Princ", supplier.getSupplier_id(), "Book", 10);
        productsService.addNewProduct(maliPrinc);
        Products igraPrestola = new Products(2,"Igra Prestola",  supplier.getSupplier_id(), "Book", 12);
        productsService.addNewProduct(igraPrestola);

        Products transformers = new Products(3,"Transformers",  supplier.getSupplier_id(), "Toy", 23);
        productsService.addNewProduct(transformers);
/*        Product legoKocke = new Products("Lego kocke", 50, 10, toy);
        productService.addNewProduct(legoKocke);*/
    }
    private static List<Products> findProductsSuppliers()throws ShopException {
        Suppliers supplier = suppliersService.findSupplier(1);
        return productsService.findAllProductWithSuppliers(supplier);
    }
    private static Employees findEmployeeId()throws ShopException {
       // Employees supplier = employeesService.findEmployeeId(1);
        return employeesService.findEmployeeId(1);
    }
    private static List<Products> findEvery()throws ShopException {
        //Suppliers supplier = suppliersService.findSupplier(1);
        return productsService.findEvery();
    }
    private static List<Customers> findEveryCustomers()throws ShopException {
        //Suppliers supplier = suppliersService.findSupplier(1);
        return customersService.findAll();
    }
    private static List<Orders> findOrders()throws ShopException {
        Customers customer = customersService.findCustomer("Anika");
        return ordersService.findAllOrdersWithCustomers(customer);//zove se sad findAllOrdersWithCustomers
    }

    private static List<Orders> listN()throws ShopException {
      return customersService.listNum();
    }
    // Assuming the return type should be a List<String>
    public static List<String> retrieveCustomerOrderInfo() throws ShopException {
        List<String> customerOrderInfo = new ArrayList<>();

        for (Customers customer : customersService.findAll()) {
            for (Orders order : ordersService.findAllOrdersWithCustomers(customer)) {
                String info = "CustomerName: " + customer.getCustomer_name() +
                        ", Order ID: " + order.getOrder_id();
                customerOrderInfo.add(info);
            }
        }

        return customerOrderInfo;
    }

    private static void findEveryCustomer()throws ShopException {
        //Suppliers supplier = suppliersService.findSupplier(1);
        for (Customers customer : customersService.findAll()) {
            for (Orders order : ordersService.findAllOrdersWithCustomers(customer)) {
                System.out.println("CustomersName: " + customer.getCustomer_name() +
                        ", Order ID: " + order.getOrder_id());
            }
        }

    }

    private static Products findProductOne()throws ShopException {
        //Suppliers supplier = suppliersService.findSupplier(1);

        return productsService.findProductWithName("Mali Princ");
    }
    private static void addTestCustomers() throws ShopException {
        Address address = new Address("Mali Zvornik", "Dositijeva", "15");
        ContactDetails contactDetails = new ContactDetails("branko.pavlovic@acme.com", "064535342825");
        Customer customer = new Customer("branko", "Branko", "Pavlovic", 100, contactDetails, address);

        customerService.addNewCustomer(customer);

        Address address1 = new Address("Loznica", "Vuka Karadzica", "24");
        ContactDetails contactDetails1 = new ContactDetails("milan.cabarkapa@acme.com", "06324567881");
        Customer customer1 = new Customer("milan", "Milan", "Cabarkapa", 150, contactDetails1, address1);

        customerService.addNewCustomer(customer1);
    }
    private static void addTestOrders() throws ShopException {
        Customers customer = customersService.findCustomer("Sonja");
        Customers customer2 = customersService.findCustomer("Neda");

        Employees employee = employeesService.findEmployeeId(1);
        Employees employee2 = employeesService.findEmployeeId(2);

        Shippers shipper = shippersService.findShipperId(1);
        Shippers shipper2 = shippersService.findShipperId(2);

        Orders order = new Orders(1,"2000-11-15", customer.getCustomer_id(),employee.getEmployee_id(),shipper.getShipper_id());
        // Suppliers supplier2 = new Suppliers(1,"Nedina", "Dragance","Djurdja Cosica","Kragujevac",34000, "Srbija",324);

        ordersService.addNewOrder(order);
        //  suppliersService.addNewSupplier(supplier2);


      /*  Address address1 = new Address("Loznica", "Vuka Karadzica", "24");
        ContactDetails contactDetails1 = new ContactDetails("milan.cabarkapa@acme.com", "06324567881");
        Customer customer1 = new Customer("milan", "Milan", "Cabarkapa", 150, contactDetails1, address1);

        customerService.addNewCustomer(customer1);*/
    }
    private static void addTestEmployee() throws ShopException {
       /* SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        Date parsedDate = null;
        try {
            parsedDate = (Date) dateFormat.parse("2000-11-15");
        } catch (ParseException e) {
            e.printStackTrace();
        }*/
        Date birthdate = Date.valueOf("2000-11-15");
       // Employees employee = new Employees(1,"Markovic", "Milan", "2013-11-08");
        // Suppliers supplier2 = new Suppliers(1,"Nedina", "Dragance","Djurdja Cosica","Kragujevac",34000, "Srbija",324);
        //Employees employee2 = new Employees(2,"Arsic", "Dragan",birthdate);

     //   employeesService.addNewEmployee(employee);
       // employeesService.addNewEmployee(employee2);
        //  suppliersService.addNewSupplier(supplier2);


      /*  Address address1 = new Address("Loznica", "Vuka Karadzica", "24");
        ContactDetails contactDetails1 = new ContactDetails("milan.cabarkapa@acme.com", "06324567881");
        Customer customer1 = new Customer("milan", "Milan", "Cabarkapa", 150, contactDetails1, address1);

        customerService.addNewCustomer(customer1);*/
    }
    private static void addTestSupplier() throws ShopException {
        Suppliers supplier = new Suppliers(1,"Neda", "Dragan","Milovana Cosica","Kragujevac",34000, "Srbija",432);
       // Suppliers supplier2 = new Suppliers(1,"Nedina", "Dragance","Djurdja Cosica","Kragujevac",34000, "Srbija",324);

        suppliersService.addNewSupplier(supplier);
      //  suppliersService.addNewSupplier(supplier2);


      /*  Address address1 = new Address("Loznica", "Vuka Karadzica", "24");
        ContactDetails contactDetails1 = new ContactDetails("milan.cabarkapa@acme.com", "06324567881");
        Customer customer1 = new Customer("milan", "Milan", "Cabarkapa", 150, contactDetails1, address1);

        customerService.addNewCustomer(customer1);*/
    }
    private static void addTestShipper() throws ShopException {
        // Customers customer = new Customers(1,"Sonja", "Mirjana","Dobrice Cosica","Kragujevac",34000, "Srbija");
        //Customers customer2 = new Customers(3,"Neda", "Miki","Dobrice Cosica","Kragujevac",34000, "Srbija");
        Shippers customer3 = new Shippers(1,"Milica",34900);
        Shippers customer4 = new Shippers(2,"Lazar",36900);

        shippersService.addNewShipper(customer3);
        shippersService.addNewShipper(customer4);


      /*  Address address1 = new Address("Loznica", "Vuka Karadzica", "24");
        ContactDetails contactDetails1 = new ContactDetails("milan.cabarkapa@acme.com", "06324567881");
        Customer customer1 = new Customer("milan", "Milan", "Cabarkapa", 150, contactDetails1, address1);

        customerService.addNewCustomer(customer1);*/
    }
    private static void addTestCustomer() throws ShopException {
       // Customers customer = new Customers(1,"Sonja", "Mirjana","Dobrice Cosica","Kragujevac",34000, "Srbija");
        //Customers customer2 = new Customers(3,"Neda", "Miki","Dobrice Cosica","Kragujevac",34000, "Srbija");
        Customers customer3 = new Customers(4,"Anika", "Plana","Dobrice Cosica","Kragujevac",34000, "Srbija");

        customersService.addNewCustomer(customer3);

      /*  Address address1 = new Address("Loznica", "Vuka Karadzica", "24");
        ContactDetails contactDetails1 = new ContactDetails("milan.cabarkapa@acme.com", "06324567881");
        Customer customer1 = new Customer("milan", "Milan", "Cabarkapa", 150, contactDetails1, address1);

        customerService.addNewCustomer(customer1);*/
    }

    private static void deleteTestCustomers() throws ShopException {
        customerService.deleteCustomer("branko");
        customerService.deleteCustomer("milan");
    }

}
