package rs.ac.fink.vezbe.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import rs.ac.fink.vezbe.data.Address;
import rs.ac.fink.vezbe.data.ContactDetails;
import rs.ac.fink.vezbe.data.Customer;

public class CustomerDao {

    private static final CustomerDao instance = new CustomerDao();

    private CustomerDao() {
    }

    public static CustomerDao getInstance() {
        return instance;
    }

    public Customer find(String username, Connection con) throws SQLException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Customer customer = null;
        try {
            ps = con.prepareStatement("SELECT * FROM customer where username=?");
            ps.setString(1, username);
            rs = ps.executeQuery();
            if (rs.next()) {
                Address address = AddressDao.getInstance().find(rs.getInt("fk_address"), con);
                ContactDetails contactDetails = ContactDetailsDao.getInstance().find(rs.getInt("fk_contact_details"), con);
                customer = new Customer(rs.getString("username"), rs.getString("name"), rs.getString("surname"),
                        rs.getDouble("credit"), contactDetails, address);
            }
        } finally {
            ResourcesManager.closeResources(rs, ps);
        }
        return customer;
    }

    public void insert(Customer customer, Connection con) throws SQLException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {

            Integer fkAddress = null;
            if (customer.getAddress() != null) {
                //insert address and receive the value of id
                fkAddress = AddressDao.getInstance().insert(customer.getAddress(), con);
            }
            Integer fkContactDetails = null;
            if (customer.getContactDetails() != null) {
                //insert contact details and receive the value of id
                fkContactDetails = ContactDetailsDao.getInstance().insert(customer.getContactDetails(), con);
            }

            ps = con.prepareStatement("INSERT INTO customer(username, name, surname, credit, fk_contact_details, fk_address) VALUES(?,?,?,?,?,?)");
            ps.setString(1, customer.getUsername());
            ps.setString(2, customer.getName());
            ps.setString(3, customer.getSurname());
            ps.setDouble(4, customer.getCredit());
            ps.setInt(5, fkContactDetails);
            ps.setInt(6, fkAddress);
            ps.executeUpdate();

        } finally {
            ResourcesManager.closeResources(rs, ps);
        }
    }

    public void update(Customer customer, Connection con) throws SQLException {
        PreparedStatement ps = null;
        try {

            ps = con.prepareStatement("UPDATE customer SET name=?, surname=?, credit=? WHERE username=?");
            ps.setString(1, customer.getName());
            ps.setString(2, customer.getSurname());
            ps.setDouble(3, customer.getCredit());
            ps.setString(4, customer.getUsername());
            ps.executeUpdate();

            if (customer.getAddress() != null) {
                AddressDao.getInstance().update(customer.getAddress(), con);
            }
            if (customer.getContactDetails() != null) {
                ContactDetailsDao.getInstance().update(customer.getContactDetails(), con);
            }

        } finally {
            ResourcesManager.closeResources(null, ps);
        }
    }

    public void delete(Customer customer, Connection con) throws SQLException {
        PreparedStatement ps = null;
        try {

            //delete purchases
            PurchaseDao.getInstance().delete(customer, con);

            //delete customer
            ps = con.prepareStatement("DELETE FROM customer WHERE username=?");
            ps.setString(1, customer.getUsername());
            ps.executeUpdate();

            //delete address
            if (customer.getAddress() != null) {
                AddressDao.getInstance().delete(customer.getAddress().getIdAddress(), con);
            }

            //delete contact details
            if (customer.getContactDetails() != null) {
                ContactDetailsDao.getInstance().delete(customer.getContactDetails().getIdContactDetails(), con);
            }

        } finally {
            ResourcesManager.closeResources(null, ps);
        }
    }
}
