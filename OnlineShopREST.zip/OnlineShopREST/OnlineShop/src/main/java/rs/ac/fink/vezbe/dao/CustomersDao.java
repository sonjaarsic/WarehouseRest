package rs.ac.fink.vezbe.dao;


import rs.ac.fink.vezbe.data.*;
import rs.ac.fink.vezbe.exception.ShopException;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class CustomersDao {

    private static final CustomersDao instance = new CustomersDao();

    private CustomersDao() {
    }

    public static CustomersDao getInstance() {
        return instance;
    }
    public Customers find(String customerName, Connection con) throws SQLException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Customers customer = null;
        try {
            ps = con.prepareStatement("SELECT * FROM customers where customer_name=?");
            ps.setString(1, customerName);
            rs = ps.executeQuery();
            if (rs.next()) {
                customer = new Customers(rs.getInt("customer_id"),
                        rs.getString("customer_name"),
                        rs.getString("contact_person"), rs.getString("address")
                        , rs.getString("city"), rs.getInt("post_code"), rs.getString("country"));
            }
        } finally {
            ResourcesManager.closeResources(rs, ps);
        }
        return customer;
    }
  /*  public List<Products> findEvery(Connection con) throws SQLException, ShopException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<Products> productsList = new ArrayList<>();
        try {
            ps = con.prepareStatement("SELECT * FROM products");
            rs = ps.executeQuery();
            while (rs.next()) {
                Suppliers supplier = SuppliersDao.getInstance().find(rs.getInt("supplier_id"), con);
                Products product = new Products(rs.getInt("product_id"),
                        rs.getString("product_name"),supplier,
                        rs.getString("product_category"),
                        rs.getDouble("price_per_unit"));
                productsList.add(product);
            }
        }
        catch (SQLException ex) {
            throw new ShopException("Failed to find products with id " , ex);
        }finally {
            ResourcesManager.closeResources(rs, ps);
        }
        return productsList;
    }*/
  public List<Orders> listCustomersOrders(Connection con) throws SQLException, ShopException {
      PreparedStatement ps = null;
      ResultSet rs = null;

      List<Orders> customerOrders;
      try {
          ps = con.prepareStatement("SELECT * FROM customers c" +
                  " JOIN orders o ON c.customer_id = o.order_id" +
                  " ORDER BY c.customer_name");
          rs = ps.executeQuery();
          customerOrders = new ArrayList<>();
          while (rs.next()) {
              Customers customer = new Customers(rs.getInt("customer_id"), rs.getString("customer_name"), rs.getString("contact_person"), rs.getString("address")
                      , rs.getString("city"), rs.getInt("post_code"), rs.getString("country"));

              Employees employee = EmployeesDao.getInstance().find(rs.getInt("employee_id"), con);
              Shippers shipper = ShippersDao.getInstance().find(rs.getInt("shipper_id"), con);
              Orders order = new Orders(rs.getInt("order_id"),
                      rs.getString("order_date"), rs.getInt("customer_id"),
                      rs.getInt("employee_id"), rs.getInt("shipper_id"));
              customerOrders.add(order);
          }

          // Print details of each customer order
          for (Orders order : customerOrders) {
              System.out.println("Customer Name: " + order.getCustomer_id() +
                      ", Order ID: " + order.getOrder_id());
          }
      } catch (SQLException ex) {
          throw new ShopException("Failed to find listCustomersOrders", ex);
      } finally {
          ResourcesManager.closeResources(rs, ps);
      }
      return customerOrders;
  }
    public List<Customers> findAll(Connection con) throws SQLException, ShopException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<Customers> customersList = new ArrayList<>();

        try {
            ps = con.prepareStatement("SELECT * FROM customers ");
            rs = ps.executeQuery();
            while (rs.next()) {
                Customers customer = new Customers(rs.getInt("customer_id"),rs.getString("customer_name"),
                        rs.getString("contact_person"), rs.getString("address")
                        ,rs.getString("city"), rs.getInt("post_code"),rs.getString("country"));
                customersList.add(customer);

            }
        }  catch (SQLException ex){
        throw new ShopException("Failed to find customer List" , ex);}
        finally {
            ResourcesManager.closeResources(rs, ps);
        }
        return customersList;
    }
    public Customers find(int customerId, Connection con) throws SQLException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Customers customer = null;
        try {
            ps = con.prepareStatement("SELECT * FROM customers where customer_id=?");
            ps.setInt(1, customerId);
            rs = ps.executeQuery();
            if (rs.next()) {
                //Address address = AddressDao.getInstance().find(rs.getInt("fk_address"), con);
               // ContactDetails contactDetails = ContactDetailsDao.getInstance().find(rs.getInt("fk_contact_details"), con);
                customer = new Customers(customerId,rs.getString("customer_name"), rs.getString("contact_person"), rs.getString("address")
                       ,rs.getString("city"), rs.getInt("post_code"),rs.getString("country"));
            }
        } finally {
            ResourcesManager.closeResources(rs, ps);
        }
        return customer;
    }
   /* public static void main(String[] args) {
        // Assuming you have a list of customers and their orders
        List<Customer> customers = getCustomersWithOrders(); // Replace this with your actual list of customers

        // Sort customers alphabetically by name
        Collections.sort(customers, Comparator.comparing(Customer::getName));

        // Sort orders for each customer by OrderId
        for (Customer customer : customers) {
            Collections.sort(customer.getOrders(), Comparator.comparing(Order::getOrderId));
        }

        // Displaying the sorted information
        for (Customer customer : customers) {
            System.out.println("Customer: " + customer.getName());
            for (Order order : customer.getOrders()) {
                System.out.println("OrderID: " + order.getOrderId());
            }
            System.out.println("-----");
        }
    }*/

    public void insert(Customers customer, Connection con) throws SQLException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {

            ps = con.prepareStatement("INSERT INTO customers(customer_name, contact_person, " +
                    "address, city, post_code, country) VALUES(?,?,?,?,?,?)", Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, customer.getCustomer_name());
            ps.setString(2, customer.getContact_person());
            ps.setString(3, customer.getAddress());
            ps.setString(4, customer.getCity());
            ps.setInt(5, customer.getPost_code());
            ps.setString(6, customer.getCountry());
            ps.executeUpdate();

        } finally {
            ResourcesManager.closeResources(rs, ps);
        }
    }

    public void update(Customers customer, Connection con) throws SQLException, ShopException {
        PreparedStatement ps = null;
        try {

            ps = con.prepareStatement("UPDATE customers SET customer_name=?,contact_person=?, address=?, city=?, post_code=?, country=?  WHERE customer_id=?");
            ps.setString(1, customer.getCustomer_name());
            ps.setString(2, customer.getContact_person());
            ps.setString(3, customer.getAddress());
            ps.setString(4, customer.getCity());
            ps.setInt(5, customer.getPost_code());
            ps.setString(6, customer.getCountry());
            ps.setInt(7, customer.getCustomer_id());

            ps.executeUpdate();


        } catch (SQLException ex) {
            throw new ShopException("Failed to update customer " + customer.getCustomer_name(), ex);
        }finally {
            ResourcesManager.closeResources(null, ps);
        }
    }
    public void delete(Customers customer, Connection con) throws SQLException {
        PreparedStatement ps = null;
        try {

            //delete customer
            ps = con.prepareStatement("DELETE FROM customers WHERE customer_name=?");
            ps.setString(1, customer.getCustomer_name());
            ps.executeUpdate();


        } finally {
            ResourcesManager.closeResources(null, ps);
        }
    }

    public void delete(int customerId, Connection con) throws SQLException {
        PreparedStatement ps = null;
        try {
            //delete purchases
           // PurchaseDao.getInstance().delete(customer, con);

            //delete customer
            ps = con.prepareStatement("DELETE FROM customers WHERE customer_id=?");
            ps.setInt(1, customerId);
            ps.executeUpdate();

        } finally {
            ResourcesManager.closeResources(null, ps);
        }
    }
}

