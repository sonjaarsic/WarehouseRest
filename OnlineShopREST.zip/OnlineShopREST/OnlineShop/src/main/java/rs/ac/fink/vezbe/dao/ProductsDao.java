package rs.ac.fink.vezbe.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import rs.ac.fink.vezbe.data.Address;
import rs.ac.fink.vezbe.data.Products;
import rs.ac.fink.vezbe.data.Suppliers;
import rs.ac.fink.vezbe.exception.ShopException;

public class ProductsDao {

    private static final ProductsDao instance = new ProductsDao();

    private ProductsDao() {
    }

    public static ProductsDao getInstance() {
        return instance;
    }

    public Products find(int productId, Connection con) throws SQLException, ShopException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Products product = null;
        try {
            ps = con.prepareStatement("SELECT * FROM products WHERE product_id=?");
            ps.setInt(1, productId);
            rs = ps.executeQuery();
            if (rs.next()) {
                product = new Products(rs.getInt("product_id"),rs.getString("product_name"),
                        rs.getInt("supplier_id"),
                        rs.getString("product_category"), rs.getDouble("price_per_unit"));
            }
        }
        catch (SQLException ex) {
            throw new ShopException("Failed to find products with id " + productId, ex);
        }finally {
            ResourcesManager.closeResources(rs, ps);
        }
        return product;
    }

    public Products find(String productName, Connection con) throws SQLException, ShopException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Products product = null;
        try {
            ps = con.prepareStatement("SELECT * FROM products WHERE product_name=?");
            ps.setString(1, productName);
            rs = ps.executeQuery();
            if (rs.next()) {
              //  Suppliers supplier = SuppliersDao.getInstance().find(rs.getInt("supplier_id"), con);
                product = new Products(rs.getInt("product_id"),rs.getString("product_name"),
                        rs.getInt("supplier_id"),
                        rs.getString("product_category"),
                        rs.getDouble("price_per_unit"));
            }
        } catch (SQLException ex) {
            throw new ShopException("Failed to find products with name " + productName, ex);
        } finally {
            ResourcesManager.closeResources(rs, ps);
        }
        return product;
    }

    public List<Products> findPwSid(Suppliers supplier, Connection con) throws SQLException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<Products> productsList = new ArrayList<>();
        try {
            ps = con.prepareStatement("SELECT * FROM products WHERE supplier_id=?");
            ps.setInt(1, supplier.getSupplier_id());
            rs = ps.executeQuery();
            while (rs.next()) {
                Products product = new Products(rs.getInt("product_id"),
                        rs.getString("product_name"),supplier.getSupplier_id(),
                        rs.getString("product_category"),
                        rs.getDouble("price_per_unit"));
                productsList.add(product);
            }
        } finally {
            ResourcesManager.closeResources(rs, ps);
        }
        return productsList;
    }
    public List<Products> findAll(Connection con) throws SQLException, ShopException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<Products> productsList = new ArrayList<>();
        try {
            ps = con.prepareStatement("SELECT * FROM products");
            rs = ps.executeQuery();
            while (rs.next()) {
               // Suppliers supplier = SuppliersDao.getInstance().find(rs.getInt("supplier_id"), con);
                Products product = new Products(rs.getInt("product_id"),
                        rs.getString("product_name"),
                        rs.getInt("supplier_id"),
                        rs.getString("product_category"),
                        rs.getDouble("price_per_unit"));
                productsList.add(product);
            }
        }
        catch (SQLException ex) {
            throw new ShopException("Failed to find products with id " , ex);
        }finally {
            ResourcesManager.closeResources(rs, ps);
        }
        return productsList;
    }
    public List<Products> findAllBySupplier(Suppliers supplier, Connection con) throws SQLException, ShopException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<Products> productsList = new ArrayList<>();
        try {
            ps = con.prepareStatement("SELECT * FROM products WHERE supplier_id=?");
            ps.setInt(1, supplier.getSupplier_id());
            rs = ps.executeQuery();

            while (rs.next()) {
                Suppliers supplier2 = SuppliersDao.getInstance().find(rs.getInt("supplier_id"), con);
                Products product = new Products(rs.getInt("product_id"),
                        rs.getString("product_name"),
                        supplier2.getSupplier_id(),
                        rs.getString("product_category"),
                        rs.getDouble("price_per_unit"));
                productsList.add(product);
            }
            for (Products product : productsList) {
                System.out.println("Supplier ID: " + product.getSupplier_id()+
                        ", Product ID: " + product.getProduct_id()+
                        ", Product Name: " + product.getProduct_name()+
                        ", Product Price Per Unit: " + product.getPrice_per_unit() +
                        ", Product Category: " + product.getProduct_category());
            }

        }
        catch (SQLException ex) {
            throw new ShopException("Failed to find products with id " + supplier.getSupplier_id(), ex);
        }finally {
            ResourcesManager.closeResources(rs, ps);
        }
        return productsList;
    }

    public void insert(Products product, Connection con) throws SQLException, ShopException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            ps = con.prepareStatement("INSERT INTO products(product_name, supplier_id," +
                    " product_category, price_per_unit) VALUES(?,?,?,?)", Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, product.getProduct_name());
            Suppliers supplier = SuppliersDao.getInstance().find(product.getSupplier_id(), con);
            if (supplier == null) {
                throw new ShopException("Supplier " + product.getSupplier_id() + " doesn't exist in database.");
            }
            ps.setInt(2, supplier.getSupplier_id());
            ps.setString(3, product.getProduct_category());
            ps.setDouble(4, product.getPrice_per_unit());
            ps.executeUpdate();

        } finally {
            ResourcesManager.closeResources(rs, ps);
        }
    }

    public void update(Products product, Connection con) throws SQLException {
        PreparedStatement ps = null;
        try {
            ps = con.prepareStatement("UPDATE products SET product_name=?, supplier_id=?, " +
                    "product_category=?, price_per_unit=? WHERE product_id=?");
            ps.setString(1, product.getProduct_name());
            ps.setInt(2, product.getSupplier_id());
            ps.setString(3, product.getProduct_category());
            ps.setDouble(4, product.getPrice_per_unit());
            ps.setInt(5, product.getProduct_id());
            ps.executeUpdate();
        } finally {
            ResourcesManager.closeResources(null, ps);
        }
    }
    public void delete(int product, Connection con) throws SQLException {
        PreparedStatement ps = null;
        try {

            //delete purchases of the product
            //PurchaseDao.getInstance().delete(product, con);

            //delete product
            ps = con.prepareStatement("DELETE FROM products WHERE product_id=?");
            ps.setInt(1, product);
            ps.executeUpdate();
        } finally {
            ResourcesManager.closeResources(null, ps);
        }
    }
    public void deleteProduct(Products product, Connection con) throws SQLException {
        PreparedStatement ps = null;
        try {

            //delete purchases of the product
            //PurchaseDao.getInstance().delete(product, con);

            //delete product
            ps = con.prepareStatement("DELETE FROM products WHERE product_id=?");
            ps.setInt(1, product.getProduct_id());
            ps.executeUpdate();
        } finally {
            ResourcesManager.closeResources(null, ps);
        }
    }
}
