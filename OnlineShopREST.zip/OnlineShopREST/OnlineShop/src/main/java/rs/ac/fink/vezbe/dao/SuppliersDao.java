package rs.ac.fink.vezbe.dao;

import java.sql.*;

import rs.ac.fink.vezbe.data.Suppliers;
import rs.ac.fink.vezbe.exception.ShopException;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class SuppliersDao {

    private static final SuppliersDao instance = new SuppliersDao();

    private SuppliersDao() {
    }

    public static SuppliersDao getInstance() {
        return instance;
    }

    public Suppliers find(int supplierId, Connection con) throws SQLException, ShopException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Suppliers supplier = null;
        try {
            ps = con.prepareStatement("SELECT * FROM suppliers where supplier_id=?");
            ps.setInt(1, supplierId);
            rs = ps.executeQuery();
            if (rs.next()) {
                supplier = new Suppliers(rs.getInt("supplier_id"),rs.getString("supplier_name"),
                        rs.getString("contact_person"),
                        rs.getString("address")
                        ,rs.getString("city"), rs.getInt("post_code"),
                        rs.getString("country"), rs.getInt("phone"));
            }
        } catch (SQLException ex) {
            throw new ShopException("Failed to find Supplier with id " + supplierId, ex);
        }finally {
            ResourcesManager.closeResources(rs, ps);
        }
        return supplier;
    }
    public List<Suppliers> findAll(Connection con) throws SQLException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<Suppliers> suppliersList = new ArrayList<>();
        try {
            ps = con.prepareStatement("SELECT * FROM suppliers");
            rs = ps.executeQuery();
            while (rs.next()) {
                Suppliers supplier = new Suppliers(rs.getInt("supplier_id"),rs.getString("supplier_name"),
                        rs.getString("contact_person"),
                        rs.getString("address")
                        ,rs.getString("city"), rs.getInt("post_code"),
                        rs.getString("country"), rs.getInt("phone"));
                suppliersList.add(supplier);
            }
        } finally {
            ResourcesManager.closeResources(rs, ps);
        }
        return suppliersList;
    }
    public void insert(Suppliers supplier, Connection con) throws SQLException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {

            ps = con.prepareStatement("INSERT INTO suppliers(supplier_name, contact_person, address, " +
                    "city, post_code, country,phone) VALUES(?,?,?,?,?,?,?)", Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, supplier.getSupplier_name());
            ps.setString(2, supplier.getContact_person());
            ps.setString(3, supplier.getAddress());
            ps.setString(4, supplier.getCity());
            ps.setInt(5, supplier.getPost_code());
            ps.setString(6, supplier.getCountry());
            ps.setInt(7, supplier.getPhone());

            ps.executeUpdate();

        } finally {
            ResourcesManager.closeResources(rs, ps);
        }

    }

    public void update(Suppliers supplier, Connection con) throws SQLException {
        PreparedStatement ps = null;
        try {

            ps = con.prepareStatement("UPDATE suppliers SET supplier_name=?,contact_person=?," +
                    " address=?, city=?, post_code=?, country=?, phone=?  WHERE supplier_id=?");
            ps.setString(1, supplier.getSupplier_name());
            ps.setString(2, supplier.getContact_person());
            ps.setString(3, supplier.getAddress());
            ps.setString(4, supplier.getCity());
            ps.setInt(5, supplier.getPost_code());
            ps.setString(6, supplier.getCountry());
            ps.setInt(7, supplier.getPhone());
            ps.setInt(8, supplier.getSupplier_id());

            ps.executeUpdate();

        } finally {
            ResourcesManager.closeResources(null, ps);
        }
    }

    public void delete(int supplierId, Connection con) throws SQLException {
        PreparedStatement ps = null;
        try {

            //delete purchases
            // PurchaseDao.getInstance().delete(customer, con);

            //delete customer
            ps = con.prepareStatement("DELETE FROM suppliers WHERE supplier_id=?");
            ps.setInt(1, supplierId);
            ps.executeUpdate();



        } finally {
            ResourcesManager.closeResources(null, ps);
        }
    }
}

