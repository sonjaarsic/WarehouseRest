package rs.ac.fink.vezbe.data;

import java.io.Serializable;

public class Category implements Serializable{
    private int idCategory=-1;
    private String name;

    public Category() {
    }

    public Category(int idCategory, String name) {
        this.idCategory = idCategory;
        this.name = name;
    }

    public Category(String name) {
        this.name = name;
    }

    public int getIdCategory() {
        return idCategory;
    }

    
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Category{").append("name=").append(name).append("}");
        return sb.toString();
    }
            
    
}
