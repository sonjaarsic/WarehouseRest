package rs.ac.fink.vezbe.data;

import java.io.Serializable;

public class ContactDetails implements Serializable{
    private int idContactDetails;
    private String emailAddress;
    private String phoneNumber;

    public ContactDetails() {
    }

    public ContactDetails(int idContactDetails, String emailAddress, String phoneNumber) {
        this.idContactDetails = idContactDetails;
        this.emailAddress = emailAddress;
        this.phoneNumber = phoneNumber;
    }

    public ContactDetails(String emailAddress, String phoneNumber) {
        this.emailAddress = emailAddress;
        this.phoneNumber = phoneNumber;
    }

    public int getIdContactDetails() {
        return idContactDetails;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("ContactDetails{").append("emailAddress=").append(emailAddress).append(", phoneNumber=").append(phoneNumber).append("}");
        return sb.toString();
    }
    
}
