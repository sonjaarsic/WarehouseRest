package rs.ac.fink.vezbe.data;

import java.io.Serializable;
import java.util.Date;

public class Order_details implements Serializable {
    private int order_details_id=-1;
    private int order_id;
    private int product_id;
    private int quantity;

    public Order_details() {
    }

    public Order_details(int order_details_id, int order_id, int product_id, int quantity) {
        this.order_details_id = order_details_id;
        this.order_id = order_id;
        this.product_id = product_id;
        this.quantity = quantity;
    }
    public Order_details(int order_id, int product_id, int quantity) {
        this.order_id = order_id;
        this.product_id = product_id;
        this.quantity = quantity;
    }

    public int getOrder_details_id() {
        return order_details_id;
    }

    public void setOrder_details_id(int order_details_id) {
        this.order_details_id = order_details_id;
    }

    public int getOrder_id() {
        return order_id;
    }

    public void setOrder_id(int order_id) {
        this.order_id = order_id;
    }

    public int getProduct_id() {
        return product_id;
    }

    public void setProduct_id(int product_id) {
        this.product_id = product_id;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    @Override
    public String toString() {
        return "Order_details{" +
                "order_details_id=" + order_details_id +
                ", order_id=" + order_id +
                ", product_id=" + product_id +
                ", quantity=" + quantity +
                '}';
    }
}
