package rs.ac.fink.vezbe.data;

import java.io.Serializable;

public class Products implements Serializable {
    private int product_id=-1;
    private String product_name;
    private int supplier_id;
    private String product_category;
    private double price_per_unit;


    public Products() {
    }

    public Products(int product_id, String product_name, int supplier_id, String product_category, double price_per_unit) {
        this.product_id = product_id;
        this.product_name = product_name;
        this.supplier_id = supplier_id;
        this.product_category = product_category;
        this.price_per_unit = price_per_unit;
    }
    public Products(String product_name, int supplier_id, String product_category, double price_per_unit) {
        this.product_name = product_name;
        this.supplier_id = supplier_id;
        this.product_category = product_category;
        this.price_per_unit = price_per_unit;
    }

    public int getProduct_id() {
        return product_id;
    }

    public void setProduct_id(int product_id) {
        this.product_id = product_id;
    }

    public String getProduct_name() {
        return product_name;
    }

    public void setProduct_name(String product_name) {
        this.product_name = product_name;
    }

    public int getSupplier_id() {
        return supplier_id;
    }

    public void setSupplier_id(int supplier_id) {
        this.supplier_id = supplier_id;
    }

    public String getProduct_category() {
        return product_category;
    }

    public void setProduct_category(String product_category) {
        this.product_category = product_category;
    }

    public double getPrice_per_unit() {
        return price_per_unit;
    }

    public void setPrice_per_unit(double price_per_unit) {
        this.price_per_unit = price_per_unit;
    }

    @Override
    public String toString() {
        return "Products{" +
                "product_id=" + product_id +
                ", product_name='" + product_name + '\'' +
                ", supplier_id=" + supplier_id +
                ", product_category='" + product_category + '\'' +
                ", price_per_unit=" + price_per_unit +
                '}';
    }
}
