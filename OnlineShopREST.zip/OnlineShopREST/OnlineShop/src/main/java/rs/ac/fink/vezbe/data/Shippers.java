package rs.ac.fink.vezbe.data;

import java.io.Serializable;

public class Shippers implements Serializable {
    private int shipper_id=-1;
    private String shipper_name;
    private int phone;

    public Shippers() {
    }

    public Shippers(int shipper_id, String shipper_name, int phone) {
        this.shipper_id = shipper_id;
        this.shipper_name = shipper_name;
        this.phone = phone;
    }
    public Shippers(String shipper_name, int phone) {
        this.shipper_name = shipper_name;
        this.phone = phone;
    }

    public int getShipper_id() {
        return shipper_id;
    }

    public void setShipper_id(int shipper_id) {
        this.shipper_id = shipper_id;
    }

    public String getShipper_name() {
        return shipper_name;
    }

    public void setShipper_name(String shipper_name) {
        this.shipper_name = shipper_name;
    }

    public int getPhone() {
        return phone;
    }

    public void setPhone(int phone) {
        this.phone = phone;
    }

    @Override
    public String toString() {
        return "Shippers{" +
                "shipper_id=" + shipper_id +
                ", shipper_name='" + shipper_name + '\'' +
                ", phone=" + phone +
                '}';
    }
}
