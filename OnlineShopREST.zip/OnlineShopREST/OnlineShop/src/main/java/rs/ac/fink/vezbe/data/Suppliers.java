package rs.ac.fink.vezbe.data;

import java.io.Serializable;

public class Suppliers implements Serializable {
    private int supplier_id=-1;
    private String supplier_name;
    private String contact_person;
    private String address;
    private String city;
    private int post_code;
    private String country;
    private int phone;

    public Suppliers() {
    }

    public Suppliers(int supplier_id, String supplier_name, String contact_person, String address, String city, int post_code, String country, int phone) {
        this.supplier_id = supplier_id;
        this.supplier_name = supplier_name;
        this.contact_person = contact_person;
        this.address = address;
        this.city = city;
        this.post_code = post_code;
        this.country = country;
        this.phone = phone;
    }
    public Suppliers(String supplier_name, String contact_person, String address, String city, int post_code, String country, int phone) {
        this.supplier_name = supplier_name;
        this.contact_person = contact_person;
        this.address = address;
        this.city = city;
        this.post_code = post_code;
        this.country = country;
        this.phone = phone;
    }

    public int getSupplier_id() {
        return supplier_id;
    }

    public void setSupplier_id(int supplier_id) {
        this.supplier_id = supplier_id;
    }

    public String getSupplier_name() {
        return supplier_name;
    }

    public void setSupplier_name(String supplier_name) {
        this.supplier_name = supplier_name;
    }

    public String getContact_person() {
        return contact_person;
    }

    public void setContact_person(String contact_person) {
        this.contact_person = contact_person;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public int getPost_code() {
        return post_code;
    }

    public void setPost_code(int post_code) {
        this.post_code = post_code;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public int getPhone() {
        return phone;
    }

    public void setPhone(int phone) {
        this.phone = phone;
    }

    @Override
    public String toString() {
        return "Suppliers{" +
                "supplier_id=" + supplier_id +
                ", supplier_name='" + supplier_name + '\'' +
                ", contact_person='" + contact_person + '\'' +
                ", address='" + address + '\'' +
                ", city='" + city + '\'' +
                ", post_code=" + post_code +
                ", country='" + country + '\'' +
                ", phone=" + phone +
                '}';
    }
}
