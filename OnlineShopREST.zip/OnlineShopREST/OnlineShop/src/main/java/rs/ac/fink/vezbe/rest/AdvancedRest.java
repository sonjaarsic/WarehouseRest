/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package rs.ac.fink.vezbe.rest;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.List;
import rs.ac.fink.vezbe.data.*;
import rs.ac.fink.vezbe.exception.ShopException;
import rs.ac.fink.vezbe.service.*;
/**
 *
 * @author DELL
 */

@Path("advanced")

public class AdvancedRest {
     private final AdvancedService advancedService = AdvancedService.getInstance();
    
    @GET
    @Path("/zad1")
    @Produces(MediaType.APPLICATION_JSON)
    public List<String> retrieveCustomerOrderInfo1() throws ShopException {
        return AdvancedService.retrieveCustomerOrderInfo1();
    }
    
    @GET
    @Path("/zad2/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public List<Products> findProductsSuppliers2(@PathParam("id") String id)throws ShopException {
        return AdvancedService.findProductsSuppliers2(Integer.parseInt(id));
    }
    @GET
    @Path("/zad3/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public List<Products> Stavka3(@PathParam("id") String id) throws ShopException {
        return AdvancedService.findShippersProduct3(Integer.parseInt(id));
    }
    @GET
    @Path("/zad4")
    @Produces(MediaType.APPLICATION_JSON)
    public List<String> totalPrice4() throws ShopException {
        return AdvancedService.totalPrice4();
    }
    @GET
    @Path("/zad5/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public List<String> priceByCustomer5(@PathParam("id") String id) throws ShopException {
        return AdvancedService.priceByCustomer5(Integer.parseInt(id));
    }
    @GET
    @Path("/zad6/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public List<String> OrderByShipper6(@PathParam("id") String id) throws ShopException {
        return AdvancedService.OrderByShipper6(Integer.parseInt(id));
    }
    @GET
    @Path("/zad7/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public List<String> OrderBySupplier7(@PathParam("id") String id) throws ShopException {
        return AdvancedService.OrderBySupplier7(Integer.parseInt(id));
    }
    @GET
    @Path("/zad8")
    @Produces(MediaType.APPLICATION_JSON)
    public Employees MaxOrderValue8() throws ShopException {
        return AdvancedService.MaxOrderValue8();
    }
    @GET
    @Path("/zad9")
    @Produces(MediaType.APPLICATION_JSON)
    public List<Products> twoProducts9() throws ShopException {
        return AdvancedService.twoProducts9();
    }
    @GET
    @Path("/zad10")
    @Produces(MediaType.APPLICATION_JSON)
    public List<AdvancedService.CustomerPrice> topFourCustomersByPricePerUnit10() throws ShopException {
        return AdvancedService.topFourCustomersByPricePerUnit10();
    }
    @GET
    @Path("/zad11")
    @Produces(MediaType.APPLICATION_JSON)
    public Suppliers MaxSupplier11() throws ShopException {
        return AdvancedService.MaxSupplier11();
    }
    
    
}
