package rs.ac.fink.vezbe.rest;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import rs.ac.fink.vezbe.data.*;
import rs.ac.fink.vezbe.exception.ShopException;
import rs.ac.fink.vezbe.service.*;

import java.util.List;
@Path("supplier")

public class SupplierRest {
    private final SuppliersService supplierService = SuppliersService.getInstance();

    @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Suppliers getSupplierById(@PathParam("id") String id) throws ShopException {
        return supplierService.findSupplier(Integer.parseInt(id));
    }

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public List<Suppliers> getAllSuppliers() throws ShopException {
        return supplierService.findAllSuppliers();
    }

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response addSupplier(Suppliers supplier) throws ShopException{
        supplierService.addNewSupplier(supplier);
        return Response.ok().build();
    }

    @PUT
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response updateSupplier(Suppliers supplier) throws ShopException {
        supplierService.updateSupplier(supplier);
        return Response.ok().build();
    }

    @DELETE
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response deleteSupplier(@PathParam("id") String id) throws ShopException {
        supplierService.deleteSupplier(Integer.parseInt(id));
        return Response.ok().build();
    }
}
