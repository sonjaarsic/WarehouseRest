package rs.ac.fink.vezbe.service;

import java.sql.Connection;
import java.sql.SQLException;
import rs.ac.fink.vezbe.dao.ResourcesManager;
import rs.ac.fink.vezbe.dao.CustomerDao;
import rs.ac.fink.vezbe.data.Customer;
import rs.ac.fink.vezbe.exception.ShopException;

public class CustomerService {

    private static final CustomerService instance = new CustomerService();

    private CustomerService() {
    }

    public static CustomerService getInstance() {
        return instance;
    }

    public void addNewCustomer(Customer customer) throws ShopException {
        Connection con = null;
        try {
            con = ResourcesManager.getConnection();

            //more than one SQL statement to execute, needs to be a single transaction
            con.setAutoCommit(false);

            CustomerDao.getInstance().insert(customer, con);

            con.commit();
        } catch (SQLException ex) {
            ResourcesManager.rollbackTransactions(con);
            throw new ShopException("Failed to add new customer " + customer, ex);
        } finally {
            ResourcesManager.closeConnection(con);
        }
    }

    public Customer findCustomer(String username) throws ShopException {
        Connection con = null;
        try {
            con = ResourcesManager.getConnection();

            return CustomerDao.getInstance().find(username, con);

        } catch (SQLException ex) {
            throw new ShopException("Failed to find customer with username " + username, ex);
        } finally {
            ResourcesManager.closeConnection(con);
        }
    }

    public void deleteCustomer(String username) throws ShopException {
        Connection con = null;
        try {
            con = ResourcesManager.getConnection();
            con.setAutoCommit(false);

            Customer customer = CustomerDao.getInstance().find(username, con);
            if (customer != null) {
                CustomerDao.getInstance().delete(customer, con);
            }

            con.commit();
        } catch (SQLException ex) {
            ResourcesManager.rollbackTransactions(con);
            throw new ShopException("Failed to delete customer with username " + username, ex);
        } finally {
            ResourcesManager.closeConnection(con);
        }
    }

    public void updateCustomer(Customer customer) throws ShopException {
        Connection con = null;
        try {
            con = ResourcesManager.getConnection();
            con.setAutoCommit(false);

            CustomerDao.getInstance().update(customer, con);

            con.commit();
        } catch (SQLException ex) {
            ResourcesManager.rollbackTransactions(con);
            throw new ShopException("Failed to update customer " + customer, ex);
        } finally {
            ResourcesManager.closeConnection(con);
        }
    }
}
