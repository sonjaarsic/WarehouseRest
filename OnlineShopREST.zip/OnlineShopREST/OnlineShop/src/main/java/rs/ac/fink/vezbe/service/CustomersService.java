package rs.ac.fink.vezbe.service;

import java.sql.Connection;
import java.sql.SQLException;

import rs.ac.fink.vezbe.dao.CustomersDao;
import rs.ac.fink.vezbe.dao.ProductsDao;
import rs.ac.fink.vezbe.dao.ResourcesManager;
import rs.ac.fink.vezbe.dao.CustomerDao;
import rs.ac.fink.vezbe.data.Customer;
import rs.ac.fink.vezbe.data.Customers;
import rs.ac.fink.vezbe.data.Orders;
import rs.ac.fink.vezbe.data.Products;
import rs.ac.fink.vezbe.exception.ShopException;
import java.util.*;
public class CustomersService {

    private static final CustomersService instance = new CustomersService();

    private CustomersService() {
    }

    public static CustomersService getInstance() {
        return instance;
    }

    public void addNewCustomer(Customers customer) throws ShopException {
        Connection con = null;
        try {
            con = ResourcesManager.getConnectionw();

            //more than one SQL statement to execute, needs to be a single transaction
            con.setAutoCommit(false);

            CustomersDao.getInstance().insert(customer, con);

            con.commit();
        } catch (SQLException ex) {
            ResourcesManager.rollbackTransactions(con);
            throw new ShopException("Failed to add new customer " + customer, ex);
        } finally {
            ResourcesManager.closeConnection(con);
        }
    }

    public Customers findCustomer(String username) throws ShopException {
        Connection con = null;
        try {
            con = ResourcesManager.getConnectionw();

            return CustomersDao.getInstance().find(username, con);

        } catch (SQLException ex) {
            throw new ShopException("Failed to find customer with name " + username, ex);
        } finally {
            ResourcesManager.closeConnection(con);
        }
    }
    public Customers findCustomerId(int usernameId) throws ShopException {
        Connection con = null;
        try {
            con = ResourcesManager.getConnectionw();

            return CustomersDao.getInstance().find(usernameId, con);

        } catch (SQLException ex) {
            throw new ShopException("Failed to find customer with id " + usernameId, ex);
        } finally {
            ResourcesManager.closeConnection(con);
        }
    }
    public List<Customers> findAll() throws ShopException {
        Connection con = null;
        try {
            con = ResourcesManager.getConnectionw();

            return CustomersDao.getInstance().findAll(con);

        } catch (SQLException ex) {
            throw new ShopException("Failed to find all customers " , ex);
        } finally {
            ResourcesManager.closeConnection(con);
        }
    }
    public  List<Orders> listNum() throws ShopException {
        Connection con = null;
        try {
            con = ResourcesManager.getConnectionw();

            return CustomersDao.getInstance().listCustomersOrders(con);

        } catch (SQLException ex) {
            throw new ShopException("Failed to find orders with suppliers id " , ex);
        } finally {
            ResourcesManager.closeConnection(con);
        }
    }




    public void deleteCustomerId(int username) throws ShopException {
        Connection con = null;
        try {
            con = ResourcesManager.getConnectionw();
            con.setAutoCommit(false);

            Customers customer = CustomersDao.getInstance().find(username, con);
            if (customer != null) {
                CustomersDao.getInstance().delete(customer.getCustomer_id(), con);
            }

            con.commit();
        } catch (SQLException ex) {
            ResourcesManager.rollbackTransactions(con);
            throw new ShopException("Failed to delete customer with id " + username, ex);
        } finally {
            ResourcesManager.closeConnection(con);
        }
    }
    public void deleteCustomer(String username) throws ShopException {
        Connection con = null;
        try {
            con = ResourcesManager.getConnectionw();
            con.setAutoCommit(false);

            Customers customer = CustomersDao.getInstance().find(username, con);
            if (customer != null) {
                CustomersDao.getInstance().delete(customer, con);
            }

            con.commit();
        } catch (SQLException ex) {
            ResourcesManager.rollbackTransactions(con);
            throw new ShopException("Failed to delete customer with username " + username, ex);
        } finally {
            ResourcesManager.closeConnection(con);
        }
    }

    public void updateCustomer(Customers customer) throws ShopException {
        Connection con = null;
        try {
            con = ResourcesManager.getConnectionw();
            con.setAutoCommit(false);

            CustomersDao.getInstance().update(customer, con);

            con.commit();
        } catch (SQLException ex) {
            ResourcesManager.rollbackTransactions(con);
            throw new ShopException("Failed to update customer " + customer, ex);
        } finally {
            ResourcesManager.closeConnection(con);
        }
    }
}
