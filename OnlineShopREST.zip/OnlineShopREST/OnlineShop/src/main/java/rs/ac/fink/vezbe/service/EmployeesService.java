package rs.ac.fink.vezbe.service;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import rs.ac.fink.vezbe.dao.CustomersDao;
import rs.ac.fink.vezbe.dao.EmployeesDao;
import rs.ac.fink.vezbe.dao.ResourcesManager;
import rs.ac.fink.vezbe.dao.ShippersDao;
import rs.ac.fink.vezbe.data.Employees;
import rs.ac.fink.vezbe.data.Shippers;
import rs.ac.fink.vezbe.exception.ShopException;

public class EmployeesService {

    private static final EmployeesService instance = new EmployeesService();

    private EmployeesService() {
    }

    public static EmployeesService getInstance() {
        return instance;
    }

    public void addNewEmployee(Employees shipper) throws ShopException {
        Connection con = null;
        try {
            con = ResourcesManager.getConnectionw();

            //more than one SQL statement to execute, needs to be a single transaction
            con.setAutoCommit(false);

            EmployeesDao.getInstance().insert(shipper, con);

            con.commit();
        } catch (SQLException ex) {
            ResourcesManager.rollbackTransactions(con);
            throw new ShopException("Failed to add new employee " + shipper, ex);
        } finally {
            ResourcesManager.closeConnection(con);
        }
    }

    public Employees findEmployeeId(int id) throws ShopException {
        Connection con = null;
        try {
            con = ResourcesManager.getConnectionw();

            return EmployeesDao.getInstance().find(id, con);

        } catch (SQLException ex) {
            throw new ShopException("Failed to find employee with id " + id, ex);
        } finally {
            ResourcesManager.closeConnection(con);
        }
    }
    public List<Employees> findAllEmployees() throws ShopException {
        Connection con = null;
        try {
            con = ResourcesManager.getConnectionw();

            return EmployeesDao.getInstance().findAll(con);

        } catch (SQLException ex) {
            throw new ShopException("Failed to find all employees", ex);
        } finally {
            ResourcesManager.closeConnection(con);
        }
    }

    public void deleteEmployee(int employeeId) throws ShopException {
        Connection con = null;
        try {
            con = ResourcesManager.getConnectionw();
            con.setAutoCommit(false);

            Employees employee = EmployeesDao.getInstance().find(employeeId, con);
            if (employee != null) {
                EmployeesDao.getInstance().delete(employeeId, con);
            }

            con.commit();
        } catch (SQLException ex) {
            ResourcesManager.rollbackTransactions(con);
            throw new ShopException("Failed to delete employee with id " + employeeId, ex);
        } finally {
            ResourcesManager.closeConnection(con);
        }
    }

    public void updateEmployee(Employees employee) throws ShopException {
        Connection con = null;
        try {
            con = ResourcesManager.getConnectionw();
            con.setAutoCommit(false);

            EmployeesDao.getInstance().update(employee, con);

            con.commit();
        } catch (SQLException ex) {
            ResourcesManager.rollbackTransactions(con);
            throw new ShopException("Failed to update employee with id " + employee.getEmployee_id(), ex);
        } finally {
            ResourcesManager.closeConnection(con);
        }
    }
}
