package rs.ac.fink.vezbe.service;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.SQLException;

import rs.ac.fink.vezbe.dao.*;
import rs.ac.fink.vezbe.data.*;
import rs.ac.fink.vezbe.exception.ShopException;
import rs.ac.fink.vezbe.exception.ShopException;
import java.util.*;
import java.util.List;

public class OrderDetailsService {

    private static final OrderDetailsService instance = new OrderDetailsService();

    public OrderDetailsService(){}

    public static OrderDetailsService getInstance() {return instance;}

    public void addNewOrderDetails(Order_details orderDetails) throws ShopException {
        Connection con = null;
        try {
            con = ResourcesManager.getConnectionw();

            //more than one SQL statement to execute, needs to be a single transaction
            con.setAutoCommit(false);

            OrderDetailsDao.getInstance().insert(orderDetails, con);

            con.commit();
        } catch (SQLException ex) {
            ResourcesManager.rollbackTransactions(con);
            throw new ShopException("Failed to add new order details " + orderDetails, ex);
        } finally {
            ResourcesManager.closeConnection(con);
        }
    }

    public Order_details findOrderDetails(int orderDetailsId) throws ShopException {
        Connection con = null;
        try {
            con = ResourcesManager.getConnectionw();

            return OrderDetailsDao.getInstance().find(orderDetailsId, con);

        } catch (SQLException ex) {
            throw new ShopException("Failed to find order details with id " + orderDetailsId, ex);
        } finally {
            ResourcesManager.closeConnection(con);
        }
    }

    public void deleteOrderDetails(int orderDetailsId) throws ShopException {
        Connection con = null;
        try {
            con = ResourcesManager.getConnectionw();
            con.setAutoCommit(false);

            Order_details orderDetails = OrderDetailsDao.getInstance().find(orderDetailsId, con);
            if (orderDetails != null) {
                OrderDetailsDao.getInstance().delete(orderDetailsId, con);
            }

            con.commit();
        } catch (SQLException ex) {
            ResourcesManager.rollbackTransactions(con);
            throw new ShopException("Failed to delete order details with id" + orderDetailsId, ex);
        } finally {
            ResourcesManager.closeConnection(con);
        }
    }

    public void updateOrderDetails(Order_details orderDetails) throws ShopException {
        Connection con = null;
        try {
            con = ResourcesManager.getConnectionw();
            con.setAutoCommit(false);

            OrderDetailsDao.getInstance().update(orderDetails, con);

            con.commit();
        } catch (SQLException ex) {
            ResourcesManager.rollbackTransactions(con);
            throw new ShopException("Failed to update order details " + orderDetails, ex);
        } finally {
            ResourcesManager.closeConnection(con);
        }
    }

    public List<Order_details> findAllOrderDetails() throws ShopException {
        Connection con = null;
        try {
            con = ResourcesManager.getConnectionw();

            return OrderDetailsDao.getInstance().findAll(con);

        } catch (SQLException ex) {
            throw new ShopException("Failed to find all order details", ex);
        } finally {
            ResourcesManager.closeConnection(con);
        }
    }
}