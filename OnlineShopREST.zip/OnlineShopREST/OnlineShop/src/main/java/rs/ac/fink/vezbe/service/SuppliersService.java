package rs.ac.fink.vezbe.service;

        import java.sql.Connection;
        import java.sql.SQLException;
        import java.util.List;

        import rs.ac.fink.vezbe.dao.ResourcesManager;
        import rs.ac.fink.vezbe.dao.CustomerDao;
        import rs.ac.fink.vezbe.dao.SuppliersDao;
        import rs.ac.fink.vezbe.data.Customer;
        import rs.ac.fink.vezbe.data.Suppliers;
        import rs.ac.fink.vezbe.exception.ShopException;

public class SuppliersService {

    private static final SuppliersService instance = new SuppliersService();

    private SuppliersService() {
    }

    public static SuppliersService getInstance() {
        return instance;
    }

    public void addNewSupplier(Suppliers supplier) throws ShopException {
        Connection con = null;
        try {
            con = ResourcesManager.getConnectionw();

            //more than one SQL statement to execute, needs to be a single transaction
            con.setAutoCommit(false);

            SuppliersDao.getInstance().insert(supplier, con);

            con.commit();
        } catch (SQLException ex) {
            ResourcesManager.rollbackTransactions(con);
            throw new ShopException("Failed to add new supplier " + supplier, ex);
        } finally {
            ResourcesManager.closeConnection(con);
        }
    }

    public Suppliers findSupplier(int id) throws ShopException {
        Connection con = null;
        try {
            con = ResourcesManager.getConnectionw();

            return SuppliersDao.getInstance().find(id, con);

        } catch (SQLException ex) {
            throw new ShopException("Failed to find supplier with id " + id, ex);
        } finally {
            ResourcesManager.closeConnection(con);
        }
    }

   /* public void deleteSupplierWithName(String username) throws ShopException {
        Connection con = null;
        try {
            con = ResourcesManager.getConnectionw();
            con.setAutoCommit(false);

            Suppliers supplier = SuppliersDao.getInstance().find(username, con);
            if (customer != null) {
                CustomerDao.getInstance().delete(customer, con);
            }

            con.commit();
        } catch (SQLException ex) {
            ResourcesManager.rollbackTransactions(con);
            throw new ShopException("Failed to delete customer with username " + username, ex);
        } finally {
            ResourcesManager.closeConnection(con);
        }
    }*/
    public void deleteSupplier(int SupplierId) throws ShopException {
        Connection con = null;
        try {
            con = ResourcesManager.getConnection();
            con.setAutoCommit(false);

            Suppliers supplier = SuppliersDao.getInstance().find(SupplierId, con);
            if (supplier != null) {
                SuppliersDao.getInstance().delete(SupplierId, con);
            }

            con.commit();
        } catch (SQLException ex) {
            ResourcesManager.rollbackTransactions(con);
            throw new ShopException("Failed to delete supplier with ID " + SupplierId, ex);
        } finally {
            ResourcesManager.closeConnection(con);
        }
    }
    public void updateSupplier(Suppliers supplier) throws ShopException {
        Connection con = null;
        try {
            con = ResourcesManager.getConnection();
            con.setAutoCommit(false);

            SuppliersDao.getInstance().update(supplier, con);

            con.commit();
        } catch (SQLException ex) {
            ResourcesManager.rollbackTransactions(con);
            throw new ShopException("Failed to update supplier " + supplier, ex);
        } finally {
            ResourcesManager.closeConnection(con);
        }
    }
    public List<Suppliers> findAllSuppliers() throws ShopException {
        Connection con = null;
        try {
            con = ResourcesManager.getConnectionw();

            return SuppliersDao.getInstance().findAll(con);

        } catch (SQLException ex) {
            throw new ShopException("Failed to find all suppliers", ex);
        } finally {
            ResourcesManager.closeConnection(con);
        }
    }
}

