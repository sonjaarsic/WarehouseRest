package rs.ac.singidunum.vezbe;

import rs.ac.singidunum.vezbe.data.Address;
import rs.ac.singidunum.vezbe.data.Category;
import rs.ac.singidunum.vezbe.data.ContactDetails;
import rs.ac.singidunum.vezbe.data.Customer;
import rs.ac.singidunum.vezbe.data.Product;
import rs.ac.singidunum.vezbe.exception.ShopException;
import rs.ac.singidunum.vezbe.service.CustomerService;
import rs.ac.singidunum.vezbe.service.ProductService;
import rs.ac.singidunum.vezbe.service.PurchaseService;

public class OnlineShopDemo {

    private static final ProductService productService = ProductService.getInstance();
    private static final CustomerService customerService = CustomerService.getInstance();
    private static final PurchaseService purchaseService = PurchaseService.getInstance();

    public static void main(String[] args) throws Exception {
        //addTestCustomers();
        //Assuming that we already have user "branko" and a product "Transformers" in database we can make the following purchase ...
				Customer korisnik = customerService.findCustomer("branko");
				Product transformersIgracka = productService.findProduct("Transformers");
				purchaseService.makePurchase(korisnik, transformersIgracka);
    }

    private static void deleteTestProducts() throws ShopException {
        productService.deleteProduct("Mali Princ");
        productService.deleteProduct("Transformers");
        productService.deleteProduct("Igra Prestola");
        productService.deleteProduct("Lego kocke");
    }

    private static void addTestCategories() throws ShopException {
        productService.addNewProductCategory(new Category("Book"));
        productService.addNewProductCategory(new Category("Toy"));
    }

    private static void addTestProducts() throws ShopException {
        Category book = productService.findProductCategory("Book");
        Category toy = productService.findProductCategory("Toy");

        Product maliPrinc = new Product("Mali Princ", 30, 10, book);
        productService.addNewProduct(maliPrinc);
        Product igraPrestola = new Product("Igra Prestola", 45, 15, book);
        productService.addNewProduct(igraPrestola);

        Product transformers = new Product("Transformers", 40, 5, toy);
        productService.addNewProduct(transformers);
        Product legoKocke = new Product("Lego kocke", 50, 10, toy);
        productService.addNewProduct(legoKocke);
    }

    private static void addTestCustomers() throws ShopException {
        Address address = new Address("Mali Zvornik", "Dositijeva", "15");
        ContactDetails contactDetails = new ContactDetails("branko.pavlovic@acme.com", "064535342825");
        Customer customer = new Customer("branko", "Branko", "Pavlovic", 100, contactDetails, address);

        customerService.addNewCustomer(customer);

        Address address1 = new Address("Loznica", "Vuka Karadzica", "24");
        ContactDetails contactDetails1 = new ContactDetails("milan.cabarkapa@acme.com", "06324567881");
        Customer customer1 = new Customer("milan", "Milan", "Cabarkapa", 150, contactDetails1, address1);

        customerService.addNewCustomer(customer1);
    }

    private static void deleteTestCustomers() throws ShopException {
        customerService.deleteCustomer("branko");
        customerService.deleteCustomer("milan");
    }

}
