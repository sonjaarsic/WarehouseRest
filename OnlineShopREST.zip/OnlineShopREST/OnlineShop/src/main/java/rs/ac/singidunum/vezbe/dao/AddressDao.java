package rs.ac.singidunum.vezbe.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import rs.ac.singidunum.vezbe.data.Address;

public class AddressDao {

    private static final AddressDao instance = new AddressDao();

    private AddressDao() {
    }

    public static AddressDao getInstance() {
        return instance;
    }

    protected Address find(int idAddress, Connection con) throws SQLException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Address address = null;
        try {
            ps = con.prepareStatement("SELECT * FROM address where id_address=?");
            ps.setInt(1, idAddress);
            rs = ps.executeQuery();
            if (rs.next()) {
                address = new Address(idAddress, rs.getString("city"), rs.getString("street"), rs.getString("street_number"));
            }
        } finally {
            ResourcesManager.closeResources(rs, ps);
        }
        return address;
    }

    protected int insert(Address address, Connection con) throws SQLException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        int id = -1;
        try {
            ps = con.prepareStatement("INSERT INTO address(city, street, street_number) VALUES(?,?,?)", Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, address.getCity());
            ps.setString(2, address.getStreet());
            ps.setString(3, address.getStreetNumber());
            ps.executeUpdate();
            rs = ps.getGeneratedKeys();
            rs.next();
            id = rs.getInt(1);
        } finally {
            ResourcesManager.closeResources(rs, ps);
        }
        return id;
    }

    public void update(Address address, Connection con) throws SQLException {
        PreparedStatement ps = null;
        try {
            ps = con.prepareStatement("UPDATE address SET city=?, street=?, street_number=? WHERE id_address=?");
            ps.setString(1, address.getCity());
            ps.setString(2, address.getStreet());
            ps.setString(3, address.getStreetNumber());
            ps.setInt(4, address.getIdAddress());
            ps.executeUpdate();
        } finally {
            ResourcesManager.closeResources(null, ps);
        }
    }

    public void delete(int idAddress, Connection con) throws SQLException {
        PreparedStatement ps = null;
        try {
            ps = con.prepareStatement("DELETE FROM address WHERE id_address=?");
            ps.setInt(1, idAddress);
            ps.executeUpdate();
        } finally {
            ResourcesManager.closeResources(null, ps);
        }
    }
}
