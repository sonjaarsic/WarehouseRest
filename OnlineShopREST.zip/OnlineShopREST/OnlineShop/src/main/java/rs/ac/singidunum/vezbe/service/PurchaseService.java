package rs.ac.singidunum.vezbe.service;

import java.sql.Connection;
import java.sql.SQLException;
import rs.ac.singidunum.vezbe.dao.ResourcesManager;
import rs.ac.singidunum.vezbe.dao.CustomerDao;
import rs.ac.singidunum.vezbe.dao.ProductDao;
import rs.ac.singidunum.vezbe.dao.PurchaseDao;
import rs.ac.singidunum.vezbe.data.Customer;
import rs.ac.singidunum.vezbe.data.Product;
import rs.ac.singidunum.vezbe.data.Purchase;
import rs.ac.singidunum.vezbe.exception.ShopException;

public class PurchaseService {

    private static final PurchaseService instance = new PurchaseService();

    private PurchaseService() {
    }

    public static PurchaseService getInstance() {
        return instance;
    }

    public void makePurchase(Customer customer, Product product) throws ShopException {
        Connection con = null;
        try {
            con = ResourcesManager.getConnection();
            con.setAutoCommit(false);

            if (product.getCount() == 0) {
                throw new ShopException("There are no more products " + product.getName() + " in the store.");
            }

            if (customer.getCredit() < product.getPrice()) {
                throw new ShopException("Customer doesn't have enough credit to make a purchase. Customer's credit is " + customer.getCredit() + ", price of the product is " + product.getPrice());
            }

            //decrease customers credit 
            double newCredit = customer.getCredit() - product.getPrice();
            customer.setCredit(newCredit);
            CustomerDao.getInstance().update(customer, con);

            //decrease number of this product in store
            product.setCount(product.getCount() - 1);
            ProductDao.getInstance().update(product, con);

            //track of purchase in database
            Purchase purchase = new Purchase(customer, product);
            PurchaseDao.getInstance().insert(purchase, con);

            con.commit();

            System.out.println("Customer " + customer.getUsername() + " purchased a product " + product.getName() + " for price " + product.getPrice());
        } catch (SQLException ex) {
            ResourcesManager.rollbackTransactions(con);
            throw new ShopException("Failed to make a purchase.", ex);
        } finally {
            ResourcesManager.closeConnection(con);
        }
    }
}
