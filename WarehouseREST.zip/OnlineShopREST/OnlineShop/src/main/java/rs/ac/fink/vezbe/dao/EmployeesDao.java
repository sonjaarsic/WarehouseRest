package rs.ac.fink.vezbe.dao;

import rs.ac.fink.vezbe.data.Employees;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class EmployeesDao {

    private static final EmployeesDao instance = new EmployeesDao();

    private EmployeesDao() {
    }

    public static EmployeesDao getInstance() {
        return instance;
    }

    public Employees find(int employeeId, Connection con) throws SQLException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Employees employee = null;
        try {
            ps = con.prepareStatement("SELECT * FROM employees WHERE employee_id=?");
            ps.setInt(1, employeeId);
            rs = ps.executeQuery();
            if (rs.next()) {

                employee = new Employees(rs.getInt("employee_id"),rs.getString("last_name"), rs.getString("first_name"), rs.getString("birth_date"));
              
            }
            
        } finally {
            ResourcesManager.closeResources(rs, ps);
        }
        return employee;
    }
    public List<Employees> findAll(Connection con) throws SQLException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<Employees> employeesList = new ArrayList<>();
        try {
            ps = con.prepareStatement("SELECT * FROM employees");
            rs = ps.executeQuery();
            while (rs.next()) {
                Employees employee = new Employees(rs.getInt("employee_id"), rs.getString("last_name"),
                        rs.getString("first_name"), rs.getString("birth_date"));
                employeesList.add(employee);
            }
        } finally {
            ResourcesManager.closeResources(rs, ps);
        }
        return employeesList;
    }
    public void insert(Employees employee, Connection con) throws SQLException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            ps = con.prepareStatement("INSERT INTO employees(last_name, first_name, birth_date) VALUES(?,?,?)", Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, employee.getLast_name());
            ps.setString(2, employee.getFirst_name());
            ps.setString(3, employee.getBirth_date());
            ps.executeUpdate();

        } finally {
            ResourcesManager.closeResources(rs, ps);
        }
    }

    public void update(Employees employee, Connection con) throws SQLException {
        PreparedStatement ps = null;
        try {

            ps = con.prepareStatement("UPDATE employees SET last_name=?, first_name=?, birth_date=? WHERE employee_id=?");
            ps.setString(1, employee.getLast_name());
            ps.setString(2, employee.getFirst_name());
            ps.setString(3, employee.getBirth_date());
            ps.setInt(4, employee.getEmployee_id());
            ps.executeUpdate();

        } finally {
            ResourcesManager.closeResources(null, ps);
        }
    }

    public void delete(int employeeId, Connection con) throws SQLException {
        PreparedStatement ps = null;
        try {

            //delete customer
            ps = con.prepareStatement("DELETE FROM employees WHERE employee_id=?");
            ps.setInt(1, employeeId);
            ps.executeUpdate();

        } finally {
            ResourcesManager.closeResources(null, ps);
        }
    }
}

