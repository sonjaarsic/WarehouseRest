


package rs.ac.fink.vezbe.dao;

        import java.sql.Connection;
        import java.sql.PreparedStatement;
        import java.sql.ResultSet;
        import java.sql.SQLException;
        import java.sql.Statement;
        import java.util.ArrayList;
        import java.util.List;
import rs.ac.fink.vezbe.data.Orders;
        import rs.ac.fink.vezbe.dao.OrdersDao;
        import rs.ac.fink.vezbe.dao.ProductsDao;
        import rs.ac.fink.vezbe.data.*;
        import rs.ac.fink.vezbe.exception.ShopException;

public class OrderDetailsDao {

    private static final OrderDetailsDao instance = new OrderDetailsDao();

    private OrderDetailsDao() {
    }

    public static OrderDetailsDao getInstance() {
        return instance;
    }

    public Order_details find(int orderDetailsId, Connection con) throws SQLException, ShopException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Order_details orderDetails = null;
        try {
            ps = con.prepareStatement("SELECT * FROM order_details WHERE order_details_id=?");
            ps.setInt(1, orderDetailsId);
            rs = ps.executeQuery();
            if (rs.next()) {
                orderDetails = new Order_details(rs.getInt("order_details_id"),
                        rs.getInt("order_id"),
                        rs.getInt("product_id"),
                        rs.getInt("quantity"));
            }
        }
        catch (SQLException ex) {
            throw new ShopException("Failed to find details for order with id  " + orderDetailsId, ex);
        }finally {
            ResourcesManager.closeResources(rs, ps);
        }
        return orderDetails;
    }
    public List<Order_details> findAll(Connection con) throws SQLException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<Order_details> ordersList = new ArrayList<>();
        try {
            ps = con.prepareStatement("SELECT * FROM order_details ");
            rs = ps.executeQuery();
            while (rs.next()) {
                Order_details order = new Order_details(rs.getInt("order_id"),
                        rs.getInt("product_id"),rs.getInt("quantity"));
                ordersList.add(order);
            }
        } finally {
            ResourcesManager.closeResources(rs, ps);
        }
        return ordersList;
    }

    public List<Order_details> findEvery(Customers customer, Connection con) throws SQLException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<Order_details> ordersList = new ArrayList<>();
        try {
            ps = con.prepareStatement("SELECT * FROM order_details WHERE customer_id=?");
            ps.setInt(1, customer.getCustomer_id());
            rs = ps.executeQuery();
            while (rs.next()) {
                Order_details order = new Order_details(rs.getInt("order_id"),
                        rs.getInt("product_id"),rs.getInt("quantity"));
                ordersList.add(order);
            }
        } finally {
            ResourcesManager.closeResources(rs, ps);
        }
        return ordersList;
    }

    public void insert(Order_details orderDetails, Connection con) throws SQLException, ShopException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            ps = con.prepareStatement("INSERT INTO order_details(order_id, product_id, " +
                    "quantity) " +
                    "VALUES(?,?,?)", Statement.RETURN_GENERATED_KEYS);
            Orders order = OrdersDao.getInstance().find(orderDetails.getOrder_id(), con);
            if (order == null) {
                throw new ShopException("Order id " + orderDetails.getOrder_id() + " doesn't exist in database.");
            }
            ps.setInt(1, order.getOrder_id());
            Products product = ProductsDao.getInstance().find(orderDetails.getProduct_id(), con);
            if (product == null) {
                throw new ShopException("Product id " + orderDetails.getProduct_id() + " doesn't exist in database.");
            }
            ps.setInt(2, orderDetails.getProduct_id());
            ps.setInt(3, orderDetails.getQuantity());

            ps.executeUpdate();
        } finally {
            ResourcesManager.closeResources(rs, ps);
        }
    }

    public void update(Order_details orderDetails, Connection con) throws SQLException {
        PreparedStatement ps = null;
        try {
            ps = con.prepareStatement("UPDATE order_details SET order_id=?, product_id=?," +
                    " quantity=? WHERE order_details_id=?");
            ps.setInt(1, orderDetails.getOrder_id());
            ps.setInt(2, orderDetails.getProduct_id());
            ps.setInt(3, orderDetails.getQuantity());
            ps.setInt(4, orderDetails.getOrder_details_id());
            ps.executeUpdate();
        } finally {
            ResourcesManager.closeResources(null, ps);
        }
    }
    public void delete(int orderDetailsId, Connection con) throws SQLException {
        PreparedStatement ps = null;
        try {

            //delete product
            ps = con.prepareStatement("DELETE FROM order_details WHERE order_details_id=?");
            ps.setInt(1, orderDetailsId);
            ps.executeUpdate();
        } finally {
            ResourcesManager.closeResources(null, ps);
        }
    }
    public void deleteOrder(Order_details orderDetails, Connection con) throws SQLException {
        PreparedStatement ps = null;
        try {

            //delete product
            ps = con.prepareStatement("DELETE FROM order_details WHERE order_details_id=?");
            ps.setInt(1, orderDetails.getOrder_details_id());
            ps.executeUpdate();
        } finally {
            ResourcesManager.closeResources(null, ps);
        }
    }
}
