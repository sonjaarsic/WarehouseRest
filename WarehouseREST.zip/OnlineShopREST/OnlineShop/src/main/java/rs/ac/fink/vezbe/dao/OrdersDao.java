package rs.ac.fink.vezbe.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import rs.ac.fink.vezbe.data.*;
import rs.ac.fink.vezbe.exception.ShopException;

public class OrdersDao {

    private static final OrdersDao instance = new OrdersDao();

    private OrdersDao() {
    }

    public static OrdersDao getInstance() {
        return instance;
    }

    public Orders find(int orderId, Connection con) throws SQLException, ShopException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Orders order = null;
        try {
            ps = con.prepareStatement("SELECT * FROM orders WHERE order_id=?");
            ps.setInt(1, orderId);
            rs = ps.executeQuery();
            if (rs.next()) {

                order = new Orders(rs.getInt("order_id"),
                        rs.getString("order_date"),
                        rs.getInt("customer_id"),
                        rs.getInt("employee_id"),
                        rs.getInt("shipper_id"));
            }
        }
        catch (SQLException ex) {
            throw new ShopException("Failed to find order with id  " + orderId, ex);
        }finally {
            ResourcesManager.closeResources(rs, ps);
        }
        return order;
    }
    public List<Orders> findEvery(Connection con) throws SQLException, ShopException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<Orders> ordersList = new ArrayList<>();

        try {
            ps = con.prepareStatement("SELECT * FROM orders");
            rs = ps.executeQuery();
            while (rs.next()) {
                int employeeId = rs.getInt("employee_id");
                int shipperId = rs.getInt("shipper_id");

                Orders order = new Orders(
                        rs.getInt("order_id"),
                        rs.getString("order_date"),
                        rs.getInt("customer_id"),
                        rs.getInt("employee_id"),
                        rs.getInt("shipper_id"));

                ordersList.add(order);
            }
        }
        catch (SQLException ex) {
            throw new ShopException("Failed to find products with idhh ", ex);
        }finally {
            ResourcesManager.closeResources(rs, ps);
        }
        return ordersList;
    }

    public List<Orders> findAll(Customers customer, Connection con) throws SQLException, ShopException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<Orders> ordersList = new ArrayList<>();

        try {
            ps = con.prepareStatement("SELECT * FROM orders WHERE customer_id=?");
            ps.setInt(1, customer.getCustomer_id());
            rs = ps.executeQuery();
            while (rs.next()) {
                int employeeId = rs.getInt("employee_id");
                int shipperId = rs.getInt("shipper_id");

                Employees employee = EmployeesDao.getInstance().find(employeeId, con);
                Shippers shipper = ShippersDao.getInstance().find(shipperId, con);

                Orders order = new Orders(
                        rs.getInt("order_id"),
                        rs.getString("order_date"),
                        customer.getCustomer_id(),
                        employee.getEmployee_id(),
                        shipper.getShipper_id()
                );
                ordersList.add(order);
            }
        }
        catch (SQLException ex) {
            throw new ShopException("Failed to find products with idhh ", ex);
        }finally {
            ResourcesManager.closeResources(rs, ps);
        }
        return ordersList;
    }


    public void insert(Orders order, Connection con) throws SQLException, ShopException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            ps = con.prepareStatement("INSERT INTO orders(order_date, customer_id, employee_id, shipper_id) " +
                    "VALUES(?,?,?,?)", Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, order.getOrder_date());
            Customers customer = CustomersDao.getInstance().find(order.getCustomer_id(), con);
            if (customer == null) {
                throw new ShopException("Customer " + order.getCustomer_id() + " doesn't exist in database.");
            }
            ps.setInt(2, order.getCustomer_id());
            Employees employee = EmployeesDao.getInstance().find(order.getEmployee_id(), con);
            if (employee == null) {
                throw new ShopException("Employee " + order.getEmployee_id() + " doesn't exist in database.");
            }
            ps.setInt(3, order.getEmployee_id());
            Shippers shipper = ShippersDao.getInstance().find(order.getShipper_id(), con);
            if (shipper == null) {
                throw new ShopException("Shipper " + order.getShipper_id() + " doesn't exist in database.");
            }
            ps.setInt(4, order.getShipper_id());
            ps.executeUpdate();

        } finally {
            ResourcesManager.closeResources(rs, ps);
        }
    }

    public void update(Orders order, Connection con) throws SQLException {
        PreparedStatement ps = null;
        try {
            ps = con.prepareStatement("UPDATE orders SET order_date=?, customer_id=?, employee_id=?, " +
                    "shipper_id=? WHERE order_id=?");
            ps.setString(1, order.getOrder_date());
            ps.setInt(2, order.getCustomer_id());
            ps.setInt(3, order.getEmployee_id());
            ps.setInt(4, order.getShipper_id());
            ps.setInt(5, order.getOrder_id());
            ps.executeUpdate();
        } finally {
            ResourcesManager.closeResources(null, ps);
        }
    }
    public void delete(int order, Connection con) throws SQLException {
        PreparedStatement ps = null;
        try {

            //delete product
            ps = con.prepareStatement("DELETE FROM orders WHERE order_id=?");
            ps.setInt(1, order);
            ps.executeUpdate();
        } finally {
            ResourcesManager.closeResources(null, ps);
        }
    }
    public void deleteOrder(Orders order, Connection con) throws SQLException {
        PreparedStatement ps = null;
        try {

            //delete product
            ps = con.prepareStatement("DELETE FROM orders WHERE order_id=?");
            ps.setInt(1, order.getOrder_id());
            ps.executeUpdate();
        } finally {
            ResourcesManager.closeResources(null, ps);
        }
    }
}
