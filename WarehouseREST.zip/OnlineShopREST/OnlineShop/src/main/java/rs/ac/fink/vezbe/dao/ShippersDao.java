package rs.ac.fink.vezbe.dao;


import rs.ac.fink.vezbe.data.Shippers;
import rs.ac.fink.vezbe.exception.ShopException;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class ShippersDao {

    private static final ShippersDao instance = new ShippersDao();

    private ShippersDao() {
    }

    public static ShippersDao getInstance() {
        return instance;
    }

    public Shippers find(int shipperId, Connection con) throws SQLException, ShopException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Shippers shipper = null;
        try {
            ps = con.prepareStatement("SELECT * FROM shippers where shipper_id=?");
            ps.setInt(1, shipperId);
            rs = ps.executeQuery();
            if (rs.next()) {
                shipper = new Shippers(rs.getInt("shipper_id"), rs.getString("shipper_name"), rs.getInt("phone"));
            }
        }
        catch (SQLException ex) {
            throw new ShopException("Failed to find " , ex);
        }finally {
            ResourcesManager.closeResources(rs, ps);
        }
        return shipper;
    }
    public List<Shippers> findAll(Connection con) throws SQLException, ShopException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<Shippers> shipperList = new ArrayList<>();

        try {
            ps = con.prepareStatement("SELECT * FROM shippers");
            rs = ps.executeQuery();
            while (rs.next()) {
                Shippers shipper = new Shippers(rs.getInt("shipper_id"), rs.getString("shipper_name"), rs.getInt("phone"));
                shipperList.add(shipper);

            }
        }
        catch (SQLException ex) {
            throw new ShopException("Failed to find list of all shippers " , ex);
        }finally {
            ResourcesManager.closeResources(rs, ps);
        }
        return shipperList;
    }


    public void insert(Shippers shipper, Connection con) throws SQLException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            ps = con.prepareStatement("INSERT INTO shippers(shipper_name,phone) VALUES(?,?)", Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, shipper.getShipper_name());
            ps.setInt(2, shipper.getPhone());
            ps.executeUpdate();


        } finally {
            ResourcesManager.closeResources(rs, ps);
        }
    }
    public void update(Shippers shipper, Connection con) throws SQLException {
        PreparedStatement ps = null;
        try {

            ps = con.prepareStatement("UPDATE shippers SET shipper_name=?,phone=?  WHERE shipper_id=?");
            ps.setString(1, shipper.getShipper_name());
            ps.setInt(2, shipper.getPhone());
            ps.setInt(3, shipper.getShipper_id());

            ps.executeUpdate();

        } finally {
            ResourcesManager.closeResources(null, ps);
        }
    }

    public void delete(int shipperId, Connection con) throws SQLException {
        PreparedStatement ps = null;
        try {
            //delete purchases
            // PurchaseDao.getInstance().delete(customer, con);

            //delete customer
            ps = con.prepareStatement("DELETE FROM shippers WHERE shipper_id=?");
            ps.setInt(1, shipperId);
            ps.executeUpdate();
        } finally {
            ResourcesManager.closeResources(null, ps);
        }
    }
}

