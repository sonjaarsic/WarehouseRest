package rs.ac.fink.vezbe.rest;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import rs.ac.fink.vezbe.data.*;
import rs.ac.fink.vezbe.exception.ShopException;
import rs.ac.fink.vezbe.service.*;

import java.util.List;

@Path("order")

public class OrderRest {
    private final OrdersService orderService = OrdersService.getInstance();

    @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Orders getCustomerById(@PathParam("id") String id) throws ShopException {
        return orderService.findOrderById(Integer.parseInt(id));
    }

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public List<Orders> getAllCustomers() throws ShopException {
        return orderService.findAllOrders();
    }

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response addOrder(Orders order) throws ShopException{
        orderService.addNewOrder(order);
        return Response.ok().build();
    }

    @PUT
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response updateOrder(Orders order) throws ShopException {
        orderService.updateOrder(order);
        return Response.ok().build();
    }

    @DELETE
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response deleteCustomer(@PathParam("id") String id) throws ShopException {
        orderService.deleteOrder(Integer.parseInt(id));
        return Response.ok().build();
    }
}
