/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rs.ac.fink.vezbe.rest;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import rs.ac.fink.vezbe.data.Products;
import rs.ac.fink.vezbe.exception.ShopException;
import rs.ac.fink.vezbe.service.ProductsService;

import java.util.List;

@Path("product")
public class ProductRest {
    private final ProductsService productsService = ProductsService.getInstance();

    @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Products getProductById(@PathParam("id") String id) throws ShopException {
        return productsService.findProduct(Integer.parseInt(id));
    }

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public List<Products> getAllProducts() throws ShopException {
        return productsService.findEvery();
    }
    
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response addProducts(Products product) throws ShopException{
        productsService.addNewProduct(product);
        return Response.ok().build();
    }



    @PUT
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response updateProducts(Products product) throws ShopException {
        productsService.updateProduct(product);
        return Response.ok().build();
    }
    

    @DELETE
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response deleteProductById(@PathParam("id") String productName) throws ShopException {
        productsService.deleteProduct(Integer.parseInt(productName));
        return Response.ok().build();
    }
}
