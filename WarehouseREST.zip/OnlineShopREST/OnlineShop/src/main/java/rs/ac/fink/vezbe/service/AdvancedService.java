package rs.ac.fink.vezbe.service;

import java.util.ArrayList;
import java.util.List;

import java.util.Collections;
import java.util.Comparator;
import rs.ac.fink.vezbe.data.*;
import rs.ac.fink.vezbe.exception.ShopException;
public class AdvancedService {

    private static final AdvancedService instance = new AdvancedService();

    public AdvancedService(){}

    public static AdvancedService getInstance(){return instance;}

    public static  CustomersService customersService = CustomersService.getInstance();
    public static  SuppliersService suppliersService = SuppliersService.getInstance();
    public static  ProductsService productsService = ProductsService.getInstance();
    public static  OrdersService ordersService = OrdersService.getInstance();
    public static  OrderDetailsService orderDetailsService = OrderDetailsService.getInstance();

    public static  ShippersService shippersService = ShippersService.getInstance();
    public static  EmployeesService employeesService = EmployeesService.getInstance();
    public static void main(String[] args) throws Exception {

        //System.out.print(retrieveCustomerOrderInfo1());
        //findProductsSuppliers2() ;
        //System.out.print(findShippersProduct3(2));
        //System.out.print(totalPrice4());
        //System.out.print(priceByCustomer5(1));
       // System.out.print(OrderByShipper6(2));
        //System.out.print(OrderBySupplier7(1));
        System.out.print(OrderBySupplier7(1));




        //  addTestCustomer();
        //addTestShipper();
        // addTestOrders();
        //  addTestEmployee();
        // retrieveCustomerOrderInfo();
        //addTestOrdersDetails();
       // listN();
        //System.out.print(listN());

        //   System.out.print(findOrders());
        //System.out.print(findEveryCustomers());
        // findEveryCustomer();
        //  addTestSupplier();
        //  addTestProduct();
        //System.out.print(findProductOne());
        //findProductOne();
        //Collections.sort(findEvery());
        //System.out.print(sort(findEvery()));
        //  System.out.print(findProductsSuppliers());
        // addTestCategories();
        //Assuming that we already have user "branko" and a product "Transformers" in database we can make the following purchase ...
        //Customer korisnik = customerService.findCustomer("branko");
        //	Product transformersIgracka = productService.findProduct("Transformers");
        //	purchaseService.makePurchase(korisnik, transformersIgracka);
    }
    public static void addTestOrdersDetails() throws ShopException {

        Order_details orderD = new Order_details(1,1, 2,20);

        orderDetailsService.addNewOrderDetails(orderD);

    }


    public static List<String> retrieveCustomerOrderInfo1() throws ShopException {
        List<String> customerOrderInfo = new ArrayList<>();

        List<Customers> customers = customersService.findAll();

        for (Customers customer : customers) {
            for (Orders order : ordersService.findAllOrdersWithCustomers(customer)) {
                String info = "CustomerName: " + customer.getCustomer_name() +
                        ", Order ID: " + order.getOrder_id();
                customerOrderInfo.add(info);
            }
        }
        Collections.sort(customerOrderInfo, Comparator.comparing(s -> s.split(": ")[1]));

        return customerOrderInfo;
    }


        public static List<Products> findProductsSuppliers2(int supplierId) throws ShopException {
        List<Products> products = productsService.findEvery();
        List<Products> productsList = new ArrayList<>();

        for (Products product : products) {
            if (product.getSupplier_id() == supplierId) {
                productsList.add(product);
            }
        }
        return productsList;
    }

    public static List<Products> findShippersProduct3(int ShipperId) throws ShopException {
        
        List<Products> products = productsService.findEvery();
        List<Orders> orders = ordersService.findAllOrders();
        List<Order_details> orderDetails = orderDetailsService.findAllOrderDetails();
        List<Products> productsList = new ArrayList<>();

        for (Orders order : orders) {
            if (order.getShipper_id() == ShipperId) {
                for (Order_details orderDetail : orderDetails) {
                    if (orderDetail.getOrder_id() == order.getOrder_id()) {
                        for (Products product : products) {
                            if (orderDetail.getProduct_id() == product.getProduct_id()) {
                                Products productNew = new Products(
                                    product.getProduct_id(),
                                    product.getProduct_name(),
                                    product.getSupplier_id(),
                                    product.getProduct_category(),
                                    product.getPrice_per_unit()
                                );
                                productsList.add(productNew);
                                break;
                            }
                        }
                    }
                }
            }
        }
        return productsList;
    }


    public static List<String> totalPrice4() throws ShopException {
        List<String> customerOrderInfo = new ArrayList<>();
        List<Products> products = productsService.findEvery();
        List<Order_details> orderDetails = orderDetailsService.findAllOrderDetails();

        double totalOrderPrice = 0.0;

        for (Products product : products) {
            double productTotalPrice = 0.0;

            for (Order_details orderDetail : orderDetails) {
                if (orderDetail.getProduct_id() == product.getProduct_id()) {
                    productTotalPrice += orderDetail.getQuantity() * product.getPrice_per_unit();
                }
            }

            totalOrderPrice += productTotalPrice;
        }

        String price = "Total price of all orders: " + String.valueOf(totalOrderPrice);
        customerOrderInfo.add(price);

        return customerOrderInfo;
    }

    public static List<String> priceByCustomer5(int CustomerId) throws ShopException {
        List<String> customerOrderInfo = new ArrayList<>();
        List<Products> products = productsService.findEvery();
        List<Orders> orders = ordersService.findAllOrders();
        List<Order_details> orderDetails = orderDetailsService.findAllOrderDetails();

        double totalCustomerPrice = 0.0;

        for (Orders order : orders) {
            if (order.getCustomer_id() == CustomerId) {
                for (Order_details orderDetail : orderDetails) {
                    for (Products product : products) {
                        if (order.getOrder_id() == orderDetail.getOrder_id()
                                && orderDetail.getProduct_id() == product.getProduct_id()) {
                            totalCustomerPrice += orderDetail.getQuantity() * product.getPrice_per_unit();
                        }
                    }
                }
            }
        }

        String price = "Total price for customer with ID " + CustomerId + ": " + String.valueOf(totalCustomerPrice);
        customerOrderInfo.add(price);

        return customerOrderInfo;
    }



    public static List<String> OrderByShipper6(int ShipperId) throws ShopException {
        List<String> customerOrderInfo = new ArrayList<>();
        List<Products> products = productsService.findEvery();
        List<Orders> orders = ordersService.findAllOrders();
        List<Order_details> orderDetails = orderDetailsService.findAllOrderDetails();

        double totalShipperPrice = 0.0;

        for (Orders order : orders) {
            if (order.getShipper_id() == ShipperId) {
                for (Order_details orderDetail : orderDetails) {
                    for (Products product : products) {
                        if (order.getOrder_id() == orderDetail.getOrder_id()
                                && orderDetail.getProduct_id() == product.getProduct_id()) {
                            totalShipperPrice += orderDetail.getQuantity() * product.getPrice_per_unit();
                        }
                    }
                }
            }
        }

        String price = "Total price for shipper with ID " + ShipperId + ": " + String.valueOf(totalShipperPrice);
        customerOrderInfo.add(price);

        return customerOrderInfo;
    }


    public static List<String> OrderBySupplier7(int SupplierId) throws ShopException {
        List<String> customerOrderInfo = new ArrayList<>();
        List<Products> products = productsService.findEvery();
        List<Suppliers> suppliers = suppliersService.findAllSuppliers();
        List<Order_details> orderDetails = orderDetailsService.findAllOrderDetails();

        for (Suppliers supplier : suppliers) {
            if (supplier.getSupplier_id() == SupplierId) {
                double totalSupplierPrice = 0.0;

                for (Order_details orderDetail : orderDetails) {
                    for (Products product : products) {
                        if (product.getSupplier_id() == supplier.getSupplier_id()
                                && product.getProduct_id() == orderDetail.getProduct_id()) {
                            totalSupplierPrice += orderDetail.getQuantity() * product.getPrice_per_unit();
                        }
                    }
                }

                String price = "Total price for supplier " + supplier.getSupplier_id() + ": " + String.valueOf(totalSupplierPrice);
                customerOrderInfo.add(price);
            }
        }

        return customerOrderInfo;
    }

    
    public static Employees MaxOrderValue8() throws ShopException {
        List<Products> products = productsService.findEvery();
        List<Employees> employees = employeesService.findAllEmployees();
        List<Orders> orders = ordersService.findAllOrders();
        List<Order_details> orderDetails = orderDetailsService.findAllOrderDetails();

        double maxTotalPrice = 0.0;
        Employees maxEmployee = null;

        for (Employees employee : employees) {
            double totalPriceForEmployee = 0.0;

            for (Orders order : orders) {
                for (Order_details orderDetail : orderDetails) {
                    for (Products product : products) {
                        if (order.getEmployee_id() == employee.getEmployee_id()
                                && order.getOrder_id() == orderDetail.getOrder_id()
                                && orderDetail.getProduct_id() == product.getProduct_id()) {
                            totalPriceForEmployee += orderDetail.getQuantity() * product.getPrice_per_unit();
                        }
                    }
                }
            }

            if (totalPriceForEmployee > maxTotalPrice) {
                maxTotalPrice = totalPriceForEmployee;
                maxEmployee = new Employees(
                    employee.getEmployee_id(),
                    employee.getLast_name(),
                    employee.getFirst_name(),
                    employee.getBirth_date()
                );
            }
        }

        return maxEmployee;
    }

     
     public static List<Products> twoProducts9() throws ShopException {
         
         
        List<Products> products = productsService.findEvery();
        List<Order_details> orderDetails = orderDetailsService.findAllOrderDetails();

        int maxQuantity = 0;
        int secondMaxQuantity = 0;
        
        Products maxProduct = null;
        Products secondMaxProduct = null;

        for (Products product : products) {
            int totalQuantity = 0;

            for (Order_details orderDetail : orderDetails) {
                if (product.getProduct_id() == orderDetail.getProduct_id()) {
                    totalQuantity += orderDetail.getQuantity();
                }
            }

            if (totalQuantity > maxQuantity) {
                secondMaxQuantity = maxQuantity;
                secondMaxProduct = maxProduct;

                maxQuantity = totalQuantity;
                
                maxProduct = new Products( product.getProduct_id(),
                    product.getProduct_name(),
                    product.getSupplier_id(),
                    product.getProduct_category(),
                    product.getPrice_per_unit()
                );
            } else if (totalQuantity > secondMaxQuantity && totalQuantity != maxQuantity) {
                secondMaxQuantity = totalQuantity;
                secondMaxProduct = new Products( product.getProduct_id(),
                    product.getProduct_name(),
                    product.getSupplier_id(),
                    product.getProduct_category(),
                    product.getPrice_per_unit()
                );
            }
        }
        List<Products> topTwoProducts = new ArrayList<>();
        
        topTwoProducts.add(maxProduct);
        topTwoProducts.add(secondMaxProduct);
        
        return topTwoProducts;
    }



    public static List<CustomerPrice> topFourCustomersByPricePerUnit10() throws ShopException{
        
        List<Customers> customers = customersService.findAll();
        List<Orders> orders = ordersService.findAllOrders();
        List<Order_details> orderDetails = orderDetailsService.findAllOrderDetails();
        List<Products> products = productsService.findEvery();

        List<CustomerPrice> topCustomers = new ArrayList<>();

        for (Customers customer : customers) {
            double totalPrice = 0.0;

            for (Orders order : orders) {
                if (order.getCustomer_id() == customer.getCustomer_id()) {
                    for (Order_details orderDetail : orderDetails) {
                        if (orderDetail.getOrder_id() == order.getOrder_id()) {
                            for (Products product : products) {
                                if (product.getProduct_id() == orderDetail.getProduct_id()) {
                                    totalPrice += orderDetail.getQuantity() * product.getPrice_per_unit();
                                    break; 
                                }
                            }
                        }
                    }
                }
            }addToTopCustomersList(topCustomers, customer, totalPrice);           
        }

        return extractTopFourCustomers(topCustomers);
    }

    private static void addToTopCustomersList(List<CustomerPrice> topCustomers, Customers customer, double totalPrice){
        CustomerPrice newCustomerPrice = new CustomerPrice(customer, totalPrice);

        if (topCustomers.size() < 4) {
            topCustomers.add(newCustomerPrice);
        } else {
            topCustomers.sort(Comparator.comparingDouble(CustomerPrice::getTotalPrice));
            if (newCustomerPrice.getTotalPrice() > topCustomers.get(0).getTotalPrice()) {
                topCustomers.set(0, newCustomerPrice);
            }
        }
    }

    private static List<CustomerPrice> extractTopFourCustomers(List<CustomerPrice> topCustomers){
       topCustomers.sort(Comparator.comparingDouble(CustomerPrice::getTotalPrice).reversed());

       return topCustomers;
    }

    public static class CustomerPrice{
        private Customers customer;
        private double totalPrice;

        @Override
        public String toString() {
            return "CustomerPrice{" + "customer=" + customer + ", totalPrice=" + totalPrice + '}';
        }
        

        public CustomerPrice(Customers customer, double totalPrice) {
            this.customer = customer;
            this.totalPrice = totalPrice;
        }

        public Customers getCustomer() {
            return customer;
        }

        public double getTotalPrice() {
            return totalPrice;
        }
        
    }


      public static Suppliers MaxSupplier11() throws ShopException{

        List<Suppliers> suppliers = suppliersService.findAllSuppliers();
        List<Products> products = productsService.findEvery();
        List<Order_details> orderDetails = orderDetailsService.findAllOrderDetails(); 
        double cena=0.0;
        double max=0.0;
        Suppliers maxSupplier=null;
        
        for (Suppliers supplier : suppliers){
            for (Products product : products){
                for (Order_details orderDetail : orderDetails){
                    if (supplier.getSupplier_id()== product.getSupplier_id() && product.getProduct_id()== orderDetail.getProduct_id()){
                        cena = cena + orderDetail.getQuantity() * product.getPrice_per_unit();
                        if (cena>max){
                            max=cena;
                           maxSupplier=new Suppliers(supplier.getSupplier_id(),supplier.getSupplier_name(),supplier.getContact_person(),
                           supplier.getAddress(),supplier.getCity(),supplier.getPost_code(),supplier.getCountry(),supplier.getPhone());
                        }
                       
                    }                                
                }
            }
        }
    return maxSupplier;
    
    }
        


}
