package rs.ac.fink.vezbe.service;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import rs.ac.fink.vezbe.dao.OrdersDao;
import rs.ac.fink.vezbe.dao.ProductsDao;
import rs.ac.fink.vezbe.dao.ResourcesManager;
import rs.ac.fink.vezbe.data.*;
import rs.ac.fink.vezbe.exception.ShopException;

public class OrdersService {

    private static final OrdersService instance = new OrdersService();

    private OrdersService() {
    }

    public static OrdersService getInstance() {
        return instance;
    }

    public void addNewOrder(Orders product) throws ShopException {
        Connection con = null;
        try {
            con = ResourcesManager.getConnectionw();

            OrdersDao.getInstance().insert(product, con);
        } catch (SQLException ex) {
            throw new ShopException("Failed to add new order " + product, ex);
        } finally {
            ResourcesManager.closeConnection(con);
        }
    }

    public Orders findOrderById(int orderId) throws ShopException {
        Connection con = null;
        try {
            con = ResourcesManager.getConnectionw();

            return OrdersDao.getInstance().find(orderId, con);

        } catch (SQLException ex) {
            throw new ShopException("Failed to find order with id " + orderId, ex);
        } finally {
            ResourcesManager.closeConnection(con);
        }
    }
    public List<Orders> findAllOrdersWithCustomers(Customers customer) throws ShopException {
        Connection con = null;
        try {
            con = ResourcesManager.getConnectionw();

            return OrdersDao.getInstance().findAll(customer, con);

        } catch (SQLException ex) {
            throw new ShopException("Failed to find all orders with customer id " + customer.getCustomer_id(), ex);
        } finally {
            ResourcesManager.closeConnection(con);
        }
    }
    public List<Orders> findAllOrders() throws ShopException {

        Connection con = null;
        try {
            con = ResourcesManager.getConnectionw();

            return OrdersDao.getInstance().findEvery(con);

        } catch (SQLException ex) {
            throw new ShopException("Failed to find all orders " , ex);
        } finally {
            ResourcesManager.closeConnection(con);
        }
    }

    public void deleteOrder(int orderId) throws ShopException {
        Connection con = null;
        try {
            con = ResourcesManager.getConnectionw();
            con.setAutoCommit(false);

            Orders order = OrdersDao.getInstance().find(orderId, con);
            if (order != null) {
                OrdersDao.getInstance().delete(orderId, con);
            }

            con.commit();
        } catch (SQLException ex) {
            ResourcesManager.rollbackTransactions(con);
            throw new ShopException("Failed to delete order with ID " + orderId, ex);
        } finally {
            ResourcesManager.closeConnection(con);
        }
    }

    public void updateOrder(Orders order) throws ShopException {
        Connection con = null;
        try {
            con = ResourcesManager.getConnectionw();
            con.setAutoCommit(false);

            OrdersDao.getInstance().update(order, con);

            con.commit();
        } catch (SQLException ex) {
            ResourcesManager.rollbackTransactions(con);
            throw new ShopException("Failed to update order " + order, ex);
        } finally {
            ResourcesManager.closeConnection(con);
        }
    }

}
