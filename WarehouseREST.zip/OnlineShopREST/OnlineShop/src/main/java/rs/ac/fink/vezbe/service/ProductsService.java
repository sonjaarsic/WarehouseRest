package rs.ac.fink.vezbe.service;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import rs.ac.fink.vezbe.dao.ProductsDao;
import rs.ac.fink.vezbe.dao.ResourcesManager;
import rs.ac.fink.vezbe.data.*;
import rs.ac.fink.vezbe.exception.ShopException;

public class ProductsService {

    private static final ProductsService instance = new ProductsService();

    private ProductsService() {
    }

    public static ProductsService getInstance() {
        return instance;
    }

    public void addNewProduct(Products product) throws ShopException {
        Connection con = null;
        try {
            con = ResourcesManager.getConnectionw();

            ProductsDao.getInstance().insert(product, con);
        } catch (SQLException ex) {
            throw new ShopException("Failed to add new product " + product, ex);
        } finally {
            ResourcesManager.closeConnection(con);
        }
    }

    public Products findProductWithName(String productName) throws ShopException {
        Connection con = null;
        try {
            con = ResourcesManager.getConnectionw();

            return ProductsDao.getInstance().find(productName, con);

        } catch (SQLException ex) {
            throw new ShopException("Failed to find product with name " + productName, ex);
        } finally {
            ResourcesManager.closeConnection(con);
        }
    }
    public Products findProduct(int productId) throws ShopException {
        Connection con = null;
        try {
            con = ResourcesManager.getConnectionw();

            return ProductsDao.getInstance().find(productId, con);

        } catch (SQLException ex) {
            throw new ShopException("Failed to find product with id " + productId, ex);
        } finally {
            ResourcesManager.closeConnection(con);
        }
    }
    public List<Products> findAllProductWithSuppliers(Suppliers supplier) throws ShopException {
        Connection con = null;
        try {
            con = ResourcesManager.getConnectionw();

            return ProductsDao.getInstance().findAllBySupplier(supplier, con);

        } catch (SQLException ex) {
            throw new ShopException("Failed to find products with supplier id " + supplier.getSupplier_id(), ex);
        } finally {
            ResourcesManager.closeConnection(con);
        }
    }
    public List<Products> findEvery() throws ShopException {
        Connection con = null;
        try {
            con = ResourcesManager.getConnectionw();

            return ProductsDao.getInstance().findAll(con);

        } catch (SQLException ex) {
            throw new ShopException("Failed to find all products" , ex);
        } finally {
            ResourcesManager.closeConnection(con);
        }
    }
    public void deleteProduct(int productId) throws ShopException {
        Connection con = null;
        try {
            con = ResourcesManager.getConnectionw();
            con.setAutoCommit(false);

            Products product = ProductsDao.getInstance().find(productId, con);
            if (product != null) {
                ProductsDao.getInstance().delete(productId, con);
            }

            con.commit();
        } catch (SQLException ex) {
            ResourcesManager.rollbackTransactions(con);
            throw new ShopException("Failed to delete product with id " + productId, ex);
        } finally {
            ResourcesManager.closeConnection(con);
        }
    }
    public void deleteProductWithName(String productName) throws ShopException {
        Connection con = null;
        try {
            con = ResourcesManager.getConnectionw();
            con.setAutoCommit(false);

            Products product = ProductsDao.getInstance().find(productName, con);
            if (product != null) {
                ProductsDao.getInstance().deleteProduct(product, con);
            }

            con.commit();
        } catch (SQLException ex) {
            ResourcesManager.rollbackTransactions(con);
            throw new ShopException("Failed to delete product with name " + productName, ex);
        } finally {
            ResourcesManager.closeConnection(con);
        }
    }

    public void updateProduct(Products product) throws ShopException {
        Connection con = null;
        try {
            con = ResourcesManager.getConnectionw();
            con.setAutoCommit(false);

            ProductsDao.getInstance().update(product, con);

            con.commit();
        } catch (SQLException ex) {
            ResourcesManager.rollbackTransactions(con);
            throw new ShopException("Failed to update product " + product, ex);
        } finally {
            ResourcesManager.closeConnection(con);
        }
    }

}
