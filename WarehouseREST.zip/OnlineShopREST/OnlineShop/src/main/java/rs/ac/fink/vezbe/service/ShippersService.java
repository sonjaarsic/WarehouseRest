package rs.ac.fink.vezbe.service;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import rs.ac.fink.vezbe.dao.CustomersDao;
import rs.ac.fink.vezbe.dao.ResourcesManager;
import rs.ac.fink.vezbe.dao.ShippersDao;
import rs.ac.fink.vezbe.data.Shippers;
import rs.ac.fink.vezbe.exception.ShopException;

public class ShippersService {

    private static final ShippersService instance = new ShippersService();

    private ShippersService() {
    }

    public static ShippersService getInstance() {
        return instance;
    }

    public void addNewShipper(Shippers shipper) throws ShopException {
        Connection con = null;
        try {
            con = ResourcesManager.getConnectionw();

            //more than one SQL statement to execute, needs to be a single transaction
            con.setAutoCommit(false);

            ShippersDao.getInstance().insert(shipper, con);

            con.commit();
        } catch (SQLException ex) {
            ResourcesManager.rollbackTransactions(con);
            throw new ShopException("Failed to add new shipper " + shipper, ex);
        } finally {
            ResourcesManager.closeConnection(con);
        }
    }

    public Shippers findShipperId(int id) throws ShopException {
        Connection con = null;
        try {
            con = ResourcesManager.getConnectionw();

            return ShippersDao.getInstance().find(id, con);

        } catch (SQLException ex) {
            throw new ShopException("Failed to find shipper with id " + id, ex);
        } finally {
            ResourcesManager.closeConnection(con);
        }
    }

    public void deleteShipper(int shipperId) throws ShopException {
        Connection con = null;
        try {
            con = ResourcesManager.getConnectionw();
            con.setAutoCommit(false);

            Shippers customer = ShippersDao.getInstance().find(shipperId, con);
            if (customer != null) {
                ShippersDao.getInstance().delete(shipperId, con);
            }

            con.commit();
        } catch (SQLException ex) {
            ResourcesManager.rollbackTransactions(con);
            throw new ShopException("Failed to delete shipper with id " + shipperId, ex);
        } finally {
            ResourcesManager.closeConnection(con);
        }
    }
    public void updateShipper(Shippers shipper) throws ShopException {
        Connection con = null;
        try {
            con = ResourcesManager.getConnectionw();
            con.setAutoCommit(false);

            ShippersDao.getInstance().update(shipper, con);

            con.commit();
        } catch (SQLException ex) {
            ResourcesManager.rollbackTransactions(con);
            throw new ShopException("Failed to update shipper " + shipper, ex);
        } finally {
            ResourcesManager.closeConnection(con);
        }
    }

    public List<Shippers> findAllShippers() throws ShopException {
        Connection con = null;
        try {
            con = ResourcesManager.getConnectionw();

            return ShippersDao.getInstance().findAll(con);

        } catch (SQLException ex) {
            throw new ShopException("Failed to find all shippers", ex);
        } finally {
            ResourcesManager.closeConnection(con);
        }
    }
    /*public void updateCustomer(Customers customer) throws ShopException {
        Connection con = null;
        try {
            con = ResourcesManager.getConnectionw();
            con.setAutoCommit(false);

            CustomersDao.getInstance().update(customer, con);

            con.commit();
        } catch (SQLException ex) {
            ResourcesManager.rollbackTransactions(con);
            throw new ShopException("Failed to update customer " + customer, ex);
        } finally {
            ResourcesManager.closeConnection(con);
        }
    }*/
}
