package rs.ac.singidunum.vezbe.data;

import java.io.Serializable;

public class Address implements Serializable{
    private int idAddress=-1;
    private String city;
    private String street;
    private String streetNumber;

    public Address() {
    }

    public Address(int idAddress, String city, String street, String streetNumber) {
        this.idAddress = idAddress;
        this.city = city;
        this.street = street;
        this.streetNumber = streetNumber;
    }

    public Address(String city, String street, String streetNumber) {
        this.city = city;
        this.street = street;
        this.streetNumber = streetNumber;
    }

    public int getIdAddress() {
        return idAddress;
    }
    

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getStreet() {
        return street;
    }

    public void setStreet(String street) {
        this.street = street;
    }

    public String getStreetNumber() {
        return streetNumber;
    }

    public void setStreetNumber(String streetNumber) {
        this.streetNumber = streetNumber;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Address{").append("city=").append(city).append(", street=").append(street).append(", streetNumber=").append(streetNumber).append("}");
        return sb.toString();
    }
    
}
