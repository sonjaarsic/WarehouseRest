package rs.ac.singidunum.vezbe.data;

import java.io.Serializable;

public class Purchase implements Serializable{

    private int idPurchase;
    private Customer customer;
    private Product product;

    public Purchase() {
    }

    public Purchase(int idPurchase, Customer customer, Product product) {
        this.idPurchase = idPurchase;
        this.customer = customer;
        this.product = product;
    }

    public Purchase(Customer customer, Product product) {
        this.customer = customer;
        this.product = product;
    }

    public int getIdPurchase() {
        return idPurchase;
    }

    public Customer getCustomer() {
        return customer;
    }

    public Product getProduct() {
        return product;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public void setProduct(Product product) {
        this.product = product;
    }
    
    

}
