/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rs.ac.singidunum.vezbe.rest;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import rs.ac.singidunum.vezbe.data.Category;
import rs.ac.singidunum.vezbe.data.Product;
import rs.ac.singidunum.vezbe.exception.ShopException;
import rs.ac.singidunum.vezbe.service.ProductService;

/**
 *
 * @author aleksandar.miljkovic
 */
@Path("product")
public class ProductRest {
    private final ProductService productService = ProductService.getInstance();
    
    @GET
    @Path("/{productName}")
    @Produces(MediaType.APPLICATION_JSON)
    public Product getProductByName(@PathParam("productName") String productName) throws ShopException {
        return productService.findProduct(productName);
    }
    
    @GET
    @Path("/category/{categoryName}")
    @Produces(MediaType.APPLICATION_JSON)
    public Category getProductByCategoryName(@PathParam("categoryName") String categoryName) throws ShopException {
        return productService.findProductCategory(categoryName);
    }
    
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response addProduct(Product product) throws ShopException{
            productService.addNewProduct(product);
            return Response.ok().build();
    }
    
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/category")
    public Response addProductCategory(Category category) throws ShopException{
            productService.addNewProductCategory(category);
            return Response.ok().build();
    }
    
    @PUT
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response updateProduct(Product product) throws ShopException {
            productService.updateProduct(product);
            return Response.ok().build();
    }
    
    @DELETE
    @Path("/{productName}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response deleteProduct(@PathParam("productName") String productName) throws ShopException {
            productService.deleteProduct(productName);
            return Response.ok().build();
    }
}
