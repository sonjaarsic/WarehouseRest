/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rs.ac.singidunum.vezbe.rest;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import rs.ac.singidunum.vezbe.data.Purchase;
import rs.ac.singidunum.vezbe.exception.ShopException;
import rs.ac.singidunum.vezbe.service.PurchaseService;

/**
 *
 * @author aleksandar.miljkovic
 */
@Path("purchase")
public class PurchaseRest {
    
    private final PurchaseService purchaseService = PurchaseService.getInstance();
    
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response makePurchase(Purchase purchase) throws ShopException{
            purchaseService.makePurchase(purchase.getCustomer(), purchase.getProduct());
            return Response.ok().build();
    }
    
}
