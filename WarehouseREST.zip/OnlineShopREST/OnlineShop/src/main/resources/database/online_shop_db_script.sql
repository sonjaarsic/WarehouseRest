CREATE SCHEMA IF NOT EXISTS `online_shop` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci ;
USE `online_shop` ;

-- -----------------------------------------------------
-- Table `online_shop`.`contact_details`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `online_shop`.`contact_details` (
  `id_contact_details` INT NOT NULL AUTO_INCREMENT,
  `email_address` VARCHAR(50) NULL,
  `phone_number` VARCHAR(50) NULL,
  PRIMARY KEY (`id_contact_details`));


-- -----------------------------------------------------
-- Table `online_shop`.`address`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `online_shop`.`address` (
  `id_address` INT NOT NULL AUTO_INCREMENT,
  `city` VARCHAR(50) NOT NULL,
  `street` VARCHAR(50) NULL,
  `street_number` VARCHAR(50) NULL,
  PRIMARY KEY (`id_address`));


-- -----------------------------------------------------
-- Table `online_shop`.`customer`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `online_shop`.`customer` (
  `username` VARCHAR(50) NOT NULL,
  `name` VARCHAR(50) NOT NULL,
  `surname` VARCHAR(50) NOT NULL,
  `credit` DECIMAL(10,2) NOT NULL DEFAULT 0,
  `fk_contact_details` INT NULL,
  `fk_address` INT NULL,
  PRIMARY KEY (`username`),
  INDEX `fk_customer_contact_details_idx` (`fk_contact_details` ASC),
  INDEX `fk_customer_address_idx` (`fk_address` ASC),
  CONSTRAINT `fk_customer_contact_details`
    FOREIGN KEY (`fk_contact_details`)
    REFERENCES `online_shop`.`contact_details` (`id_contact_details`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_customer_address`
    FOREIGN KEY (`fk_address`)
    REFERENCES `online_shop`.`address` (`id_address`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION);


-- -----------------------------------------------------
-- Table `online_shop`.`category`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `online_shop`.`category` (
  `id_category` INT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(50) NOT NULL,
  PRIMARY KEY (`id_category`),
  UNIQUE INDEX `name_UNIQUE` (`name` ASC));


-- -----------------------------------------------------
-- Table `online_shop`.`product`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `online_shop`.`product` (
  `id_product` INT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(100) NOT NULL,
  `price` DECIMAL(10,2) NOT NULL,
  `count` INT NOT NULL DEFAULT 0,
  `fk_category` INT NOT NULL,
  PRIMARY KEY (`id_product`),
  INDEX `fk_product_category_idx` (`fk_category` ASC),
  CONSTRAINT `fk_product_category`
    FOREIGN KEY (`fk_category`)
    REFERENCES `online_shop`.`category` (`id_category`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION);


-- -----------------------------------------------------
-- Table `online_shop`.`purchase`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `online_shop`.`purchase` (
  `id_purchase` INT NOT NULL AUTO_INCREMENT,
  `fk_customer` VARCHAR(50) NOT NULL,
  `fk_product` INT NOT NULL,
  PRIMARY KEY (`id_purchase`, `fk_customer`, `fk_product`),
  INDEX `fk_customer_has_product_product_idx` (`fk_product` ASC),
  INDEX `fk_customer_has_product_customer_idx` (`fk_customer` ASC),
  CONSTRAINT `fk_purchase_customer`
    FOREIGN KEY (`fk_customer`)
    REFERENCES `online_shop`.`customer` (`username`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_purchase_product`
    FOREIGN KEY (`fk_product`)
    REFERENCES `online_shop`.`product` (`id_product`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION);
